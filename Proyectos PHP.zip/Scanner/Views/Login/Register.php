<script>
    if (!!window.performance && window.performance.navigation.type === 2) {
        window.location.reload()
    }
</script>
<!DOCTYPE html>
<html>
    <head>
        <title>Registrar - Scanner | Totalsec</title>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Content-Language" content="es" />
        <meta name="author" content="" />
        <meta name="copyright" content="" />
        <meta name="description" content="" />
        <meta name="keywords" content="" /> 
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
        <link href="<?= DIRECTORIOWEB ?>Public/img/TS50x50.png" rel="shortcut icon" type="image/x-icon" />

        <!-- Bootstrap CSS -->
        <link href="<?= DIRECTORIOWEB ?>Public/css/bootstrap.css" rel="stylesheet" />

        <!-- jQuery UI -->
        <link rel="stylesheet" href="<?= DIRECTORIOWEB ?>Public/css/jquery-ui.css">

        <!-- Font Awesome Icons -->
        <link href="<?= DIRECTORIOWEB ?>Public/Plugins/font-awesome/css/font-awesome.min.css" type="text/css" rel="stylesheet" />

        <!-- Global Styles -->
        <link rel="stylesheet" type="text/css" href="<?= DIRECTORIOWEB ?>Public/css/layout.css">
        <link rel="stylesheet" type="text/css" href="<?= DIRECTORIOWEB ?>Public/css/elements.css">

        <!-- Google Font: Source Sans Pro -->
        <link href="<?= DIRECTORIOWEB ?>Public/css/fonts.googleapis.css" rel="stylesheet" rel="stylesheet" type="text/css" />

        <!-- Mis Estilos -->
        <link href="<?= DIRECTORIOWEB ?>/Public/css/style.css" rel="stylesheet" type="text/css" />

        <!--[if lt IE 9]>
                <script src="js/html5shiv.js"></script>
                <script src="js/respond.min.js"></script>
        <![endif]-->
        <!--[if lt IE 8]>
                <link href="css/libs/font-awesome-ie7.css" type="text/css" rel="stylesheet" />
        <![endif]-->
        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '<?= DIRECTORIOWEB ?>Public/js/google-analytics.js', 'ga');

            ga('create', 'UA-49262924-1', 'phoonio.com');
            ga('send', 'pageview');

        </script>
    </head>
    <body id="login-page-full" ondragstart="return false">

        <header class="navbar hidden-xs hidden-sm" id="header-navbar">
            <div class="container">
                <a href="index-2.html" id="logo" class="navbar-brand col-md-3 col-sm-3 col-xs-12" style="margin-top: -20px;">
                    <img src="<?= DIRECTORIOWEB ?>Public/img/LogoN.png" alt="" style="height: 60px;" />
                </a>
            </div>
        </header>

        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12">
                    <div id="login-box" style="margin-top: 25px">
                        <div class="row">
                            <div class="col-xs-12 clearfix" id="login-box-header">
                                <div class="login-box-header-ts"></div>
                                <div class="login-box-header-ts"></div>
                                <div class="login-box-header-ts"></div>
                                <div class="login-box-header-ts"></div>
                                <div class="login-box-header-ts"></div>
                                <div class="login-box-header-ts"></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12" style="margin-bottom: 20px">
                                <div id="login-box-inner">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="text-align: center;">
                                            <label class="login-txt">Crear Cuenta</label>
                                        </div>
                                    </div>

                                    <form method="POST" action="<?= DIRECTORIOWEB ?>Login/ValidateRegister" onsubmit="validarRegistro(event, this)" autocomplete="off">

                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtNombre" name="txtNombre" placeholder="Nombre(s)" title="Nombre(s)" maxlength="200" onkeyup="validarEntrada(this)" value="Carmelo" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtAPaterno" name="txtAPaterno" placeholder="Apellido" title="Apellido" maxlength="200" onkeyup="validarEntrada(this)" value="Rodriguez" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <br />


                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtCorreo" name="txtCorreo" placeholder="Correo" title="Correo" maxlength="200" onkeyup="validarEntrada(this)" value="isc.carrg@gmail.com" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtTelefono" name="txtTelefono" placeholder="Teléfono" title="Teléfono" onkeyup="validarEntrada(this)" value="0123456789" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <br />


                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtCelular" name="txtCelular" placeholder="Celular" title="Celular" onkeyup="validarEntrada(this)" value="0123456789" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtCompania" name="txtCompania" placeholder="Compañía" title="Compañía" maxlength="200" onkeyup="validarEntrada(this)" value="Telcel" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <br />


                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtEmpresa" name="txtEmpresa" placeholder="Nombre de la empresa" title="Nombre de la empresa" maxlength="200" onkeyup="validarEntrada(this)" value="Totalsec" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtGiroEmpresa" name="txtGiroEmpresa" placeholder="Giro de la empresa" title="Giro de la empresa" maxlength="200" onkeyup="validarEntrada(this)" value="Tecnologías de la información" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <br />


                                        <!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-top: 15px">
                                            <div class="form-group">

                                                <div class="input-group">
                                                    <div class="input-group-btn">
                                                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="#">Action</a></li>
                                                            <li><a href="#">Another action</a></li>
                                                            <li><a href="#">Something else here</a></li>
                                                            <li class="divider"></li>
                                                            <li><a href="#">Separated link</a></li>
                                                        </ul>
                                                    </div>
                                                    <input type="text" class="form-control" id="examplePrependDropdown">
                                                </div>
                                            </div>
                                        </div> -->

                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtPais" name="txtPais" placeholder="País" title="País" maxlength="200" onkeyup="validarEntrada(this)" value="México" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <input class="effect-2 tooltip-filtro" type="text" id="txtEstado" name="txtEstado" placeholder="Estado" title="Estado" maxlength="200" onkeyup="validarEntrada(this)" value="CDMX" />
                                            <span class="focus-border"></span>
                                        </div>
                                        <br />


                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 15px">
                                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                                <input class="effect-2 tooltip-filtro" type="text" id="txtCodigoPostal" name="txtCodigoPostal" placeholder="Código Postal" title="Código Postal" onkeyup="validarEntrada(this)" value="62785" />
                                                <span class="focus-border"></span>
                                            </div>                                            
                                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-top: 20px">
                                                <div class="accept-line clearfix registration-chk"><input name="chbxPrivacidad" id="chbxPrivacidad" type="checkbox" /> <span>He leído y acepto el <a target="_blank" href="#">aviso de privacidad</a></span></div>
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 20px">
                                            <div class="g-recaptcha" data-sitekey="6Le6nGYUAAAAAMSEEt9nUU8wZhxo0s5FZQXNmNhB" data-callback="approved" data-expired-callback="expired" tabindex="14"></div>
                                            <input type="hidden" class="recaptcha" name="recaptcha" id="recaptcha" required hidden="true">
                                        </div>

                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 20px">
                                            ¿Ya eres miembro? <a href="<?= DIRECTORIOWEB ?>Login">Inicia sesión</a>
                                        </div>

                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="margin-top: 20px">
                                            <button type="submit" class="btn btn-block btn-login" id="btnRegistrar"><i class="fa fa-id-card" aria-hidden="true"></i>&nbsp;&nbsp;Crear Cuenta</button>
                                        </div>

                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-top: 15px">
                                            <div class="alert <?= $vistaClaseAlerta ?> alert-dismissible fade in" <?= $vistaHiddenAlerta == NULL ? 'hidden="true"' : $vistaHiddenAlerta; ?>>
                                                <button type="button" class="close" aria-hidden="true" onclick="$(this).parent().hide()">×</button>
                                                <span class="alert-txt"><?= $vistaAlerta ?></span>
                                            </div>
                                        </div>

                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="text-center login-create">
                        Not a member? <a href="#">Register now</a>
                    </div> -->
                </div>
            </div>
        </div>
        <!-- jQuery -->
        <script src="<?= DIRECTORIOWEB ?>Public/js/jquery.min.js"></script>

        <!-- Bootstrap -->
        <script src="<?= DIRECTORIOWEB ?>Public/js/bootstrap.js"></script>

        <!-- jQuery UI -->
        <script src="<?= DIRECTORIOWEB ?>Public/js/jquery-ui.js"></script>

        <!-- Theme Scripts -->
        <script src="<?= DIRECTORIOWEB ?>Public/js/scriptsTemplate.js"></script>

        <!-- reCapcha -->
        <script src="https://www.google.com/recaptcha/api.js"></script>

        <!-- Mi Script -->
        <script src="<?= DIRECTORIOWEB ?>Public/js/script.js"></script>

        <script>
                                                    function approved() {
                                                        $('#recaptcha').val(grecaptcha.getResponse())
                                                    }
                                                    function expired() {
                                                        $('#recaptcha').val('')
                                                    }
        </script>
    </body>
</html>

