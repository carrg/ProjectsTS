<?php
$titulo = 'Principal';
$css = '';
$script = '';
$template = new Template($titulo, $css, $script);
$template->run();
?>
<h1>Estas en la página principal</h1>
<br /><br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button onclick="cerrarSesion()">Cerrar sesión</button>