<?php

class Template {

    private $titulo;
    private $css;
    private $script;

    function __construct($titulo, $css, $script) {
        $this->titulo = $titulo;
        $this->css = $css;
        $this->script = $script;
        ?>
        <!DOCTYPE html>
        <html>
            <head>
                <title><?= $this->titulo ?> - Scanner | Totalsec</title>
                <meta charset="utf-8" />
                <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                <meta http-equiv="Content-Language" content="es" />
                <meta name="author" content="" />
                <meta name="copyright" content="" />
                <meta name="description" content="" />
                <meta name="keywords" content="" /> 
                <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
                <link href="<?= DIRECTORIOWEB ?>Public/img/TS50x50.png" rel="shortcut icon" type="image/x-icon" />

                <!-- Bootstrap CSS -->
                <link href="<?= DIRECTORIOWEB ?>Public/css/bootstrap.css" rel="stylesheet" />

                <!-- jQuery UI -->
                <link rel="stylesheet" href="<?= DIRECTORIOWEB ?>Public/css/jquery-ui.css">

                <!-- Font Awesome Icons -->
                <link href="<?= DIRECTORIOWEB ?>Public/Plugins/font-awesome/css/font-awesome.min.css" type="text/css" rel="stylesheet" />

                <!-- Global Styles -->
                <link rel="stylesheet" type="text/css" href="<?= DIRECTORIOWEB ?>Public/css/layout.css">
                <link rel="stylesheet" type="text/css" href="<?= DIRECTORIOWEB ?>Public/css/elements.css">

                <!-- Google Font: Source Sans Pro -->
                <link href="<?= DIRECTORIOWEB ?>Public/css/fonts.googleapis.css" rel="stylesheet" rel="stylesheet" type="text/css" />

                <!-- Mis Estilos -->
                <link href="<?= DIRECTORIOWEB ?>/Public/css/style.css" rel="stylesheet" type="text/css" />

                <?= $this->css ?>

                <!--[if lt IE 9]>
                        <script src="js/html5shiv.js"></script>
                        <script src="js/respond.min.js"></script>
                <![endif]-->
                <!--[if lt IE 8]>
                        <link href="css/libs/font-awesome-ie7.css" type="text/css" rel="stylesheet" />
                <![endif]-->
                <script>
                    (function (i, s, o, g, r, a, m) {
                        i['GoogleAnalyticsObject'] = r;
                        i[r] = i[r] || function () {
                            (i[r].q = i[r].q || []).push(arguments)
                        }, i[r].l = 1 * new Date();
                        a = s.createElement(o),
                                m = s.getElementsByTagName(o)[0];
                        a.async = 1;
                        a.src = g;
                        m.parentNode.insertBefore(a, m)
                    })(window, document, 'script', '<?= DIRECTORIOWEB ?>Public/js/google-analytics.js', 'ga');

                    ga('create', 'UA-49262924-1', 'phoonio.com');
                    ga('send', 'pageview');

                </script>
            </head>
            <body id="login-page-full" ondragstart="return false">
                <?php
            }

            public function __call($name, $arguments) {
                
            }

            function __destruct() {
                ?>
                <!-- jQuery -->
                <script src="<?= DIRECTORIOWEB ?>Public/js/jquery.min.js"></script>

                <!-- Bootstrap -->
                <script src="<?= DIRECTORIOWEB ?>Public/js/bootstrap.js"></script>

                <!-- jQuery UI -->
                <script src="<?= DIRECTORIOWEB ?>Public/js/jquery-ui.js"></script>

                <!-- Theme Scripts -->
                <script src="<?= DIRECTORIOWEB ?>Public/js/scriptsTemplate.js"></script>

                <!-- Mi Script -->
                <script src="<?= DIRECTORIOWEB ?>Public/js/script.js"></script>

                <?= $this->script ?>
            </body>
        </html>
        <?php
    }

}
?>
