<?php

session_start();

require 'config.php';

spl_autoload_register(function ( $class ) {
    if (file_exists(MODELS . $class . '.php')) {
        require MODELS . $class . '.php';
    }
    if (file_exists(VIEWS . $class . '.php')) {
        require VIEWS . $class . '.php';
    }
    if (file_exists(CONTROLLERS . $class . '.php')) {
        require CONTROLLERS . $class . '.php';
    }
    if (file_exists(LIBS . $class . '.php')) {
        require LIBS . $class . '.php';
    }
});

$controlador = 'Login';
$metodo = 'Index';

if (isset($_GET['url']) && sizeof($_GET) > 0) {
    $controladorMetodo = explode('/', filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));
    if (sizeof($controladorMetodo) <= 2) {
        if (file_exists(CONTROLLERS . ucwords($controladorMetodo[0]) . 'Controller.php')) {
            $controlador = ucwords($controladorMetodo[0]);
            if (isset($controladorMetodo[1])) {
                if (method_exists(ucwords($controladorMetodo[0]) . 'Controller', ucwords($controladorMetodo[1])))
                    $metodo = ucwords($controladorMetodo[1]);
                else
                    $controlador = 'Error';
            } else
                $metodo = 'Index';
        } else
            $controlador = 'Error';
    } else
        $controlador = 'Error';
}

ini_set('display_errors', 1);
error_reporting(E_ALL);
set_error_handler('log_error', E_ALL);

// Desactivar toda notificación de error
// ini_set('display_errors', 0);
// error_reporting(0);

function log_error($tipo, $error, $archivo, $linea, $context) {
    call_user_func([new DB(), 'registrarError'], $tipo, $error, $archivo, $linea, $context, isset($_SESSION['idUsuarioTotalScanner']) ? $_SESSION['idUsuarioTotalScanner'] : 0, MisFunciones::getIP(), MisFunciones::getPlataforma(), MisFunciones::getNavegador(), MisFunciones::getPCName(), MisFunciones::getPCRed());

    if ($tipo == 1 || $tipo == 2) {
        header('Location: ' . DIRECTORIOWEB . 'Error/Unknown');
        die();
    }
}

$nombreClase = $controlador . 'Controller';
call_user_func([new $nombreClase($controlador, $metodo), $metodo], null);
?>
