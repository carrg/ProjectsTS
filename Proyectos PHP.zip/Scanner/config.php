<?php
$protocolo = stripos($_SERVER['SERVER_PROTOCOL'],'https') === true ? 'https://' : 'http://';
$dir = $protocolo.$_SERVER['HTTP_HOST'].'/totalsec/Scanner/';
define('DIRECTORIOWEB', $dir);

define('MODELS' , './Models/');
define('VIEWS' , './Views/');
define('CONTROLLERS' , './Controllers/');
define('LIBS' , './Libs/');

define('DB_HOST' , 'localhost');
define('DB_USER' , 'root');
define('DB_PASS' , 'Segurid@dTs2016');
define('DB_NAME' , 'test_scanner');
define('DB_PORT' , 3306);
define('CHARSET' , 'utf8');

define('CARRG' , 'CarRG');
?>

