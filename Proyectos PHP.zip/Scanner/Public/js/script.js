'use strict'

var $ = jQuery.noConflict()
var $ = $.noConflict()

$.xhrPool = []
$.CarRG = null
$.path = '/totalsec/Scanner/'

var gralesJS = document.createElement('script')
gralesJS.type = 'text/javascript'
gralesJS.src = $.path + 'Public/js/GralScript.js'
document.head.appendChild(gralesJS)

window.onload = function () {

    $('#mostrarContrasena').on('change', function (event) {
        if ($('#mostrarContrasena').is(':checked')) {
            $('#txtContrasena').get(0).type = 'text'
        } else {
            $('#txtContrasena').get(0).type = 'password'
        }
    })

    $('#mostrarContrasenaR').on('change', function (event) {
        if ($('#mostrarContrasenaR').is(':checked')) {
            $('#txtContrasenaR').get(0).type = 'text'
        } else {
            $('#txtContrasenaR').get(0).type = 'password'
        }
    })

    var $title = $("a.tooltip-filtro,p.tooltip-filtro,label.tooltip-filtro,input.tooltip-filtro,textarea.tooltip-filtro")
    $.each($title, function (index, value) {
        try {
            $(this).tooltip({
                position: {
                    my: "center bottom",
                    at: "center top-10",
                    collision: "flip",
                    using: function (position, feedback) {
                        var posTop = position.top

                        if (feedback.vertical === "bottom")
                            posTop = position.top + 13
                        else
                            posTop = position.top + 3

                        $(this).addClass(feedback.vertical)
                                .css({top: posTop, left: position.left})

                        $(this).addClass("tooltip-required")
                    }
                },
                content: function () {
                    return '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + $(this).prop('title')
                },
            }).on("mouseout", function (e) {
                if ($(this).is(":focus")) {
                    e.stopImmediatePropagation()
                }
            }).on("focusout", function () {
                $(this).tooltip("close")
            })
        } catch (err) {
        }
    })
}

function validarAccesos(event, self) {
    try {
        limpiarAlert()
        abrirModalProcesando()
        var arrayParams = new Array()
        var objParams = new Object()

        objParams.id = 'txtUsuario'
        objParams.valor = $('#txtUsuario').val() == undefined ? '' : $('#txtUsuario').val()
        objParams.requerido = true
        objParams.tipo = 'correo'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtContrasena'
        objParams.valor = $('#txtContrasena').val() == undefined ? '' : $('#txtContrasena').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'recaptcha'
        objParams.valor = $('#recaptcha').val() == undefined ? '' : $('#recaptcha').val()
        objParams.requerido = true
        objParams.tipo = 'recaptcha'
        arrayParams.push(objParams)
        objParams = {}

        var respCampos = validarCamposInput(arrayParams, 'submit')

        if (!respCampos.resp) {
            cerrarModalProcesando()
            var id = respCampos.id
            document.body.scrollTop = $('#' + id).offset().top
            if (id === 'recaptcha' && respCampos.error == 1) {
                $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Completa el CAPTCHA para continuar.')
                $('.alert-dismissible').addClass('alert-warning')
                $('.alert-dismissible').show()
                document.body.scrollTop = $('.alert-dismissible').offset().top
            }
            $('#' + id).tooltip('option', 'content', '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + dicInputsValidaciones.numError(respCampos.error));
            $('#' + id).tooltip("open")
            $('#' + id).focus()
            event.preventDefault()
        }
    } catch (err) {
        event.preventDefault()
        cerrarModalProcesando()
    }
}

function validarRegistro(event, self) {
    try {
        limpiarAlert()
        abrirModalProcesando()
        var arrayParams = new Array()
        var objParams = new Object()

        objParams.id = 'txtNombre'
        objParams.valor = $('#txtNombre').val() == undefined ? '' : $('#txtNombre').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtAPaterno'
        objParams.valor = $('#txtAPaterno').val() == undefined ? '' : $('#txtAPaterno').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtCorreo'
        objParams.valor = $('#txtCorreo').val() == undefined ? '' : $('#txtCorreo').val()
        objParams.requerido = true
        objParams.tipo = 'correo'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtTelefono'
        objParams.valor = $('#txtTelefono').val() == undefined ? '' : $('#txtTelefono').val()
        objParams.requerido = true
        objParams.tipo = 'telefono'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtCelular'
        objParams.valor = $('#txtCelular').val() == undefined ? '' : $('#txtCelular').val()
        objParams.requerido = true
        objParams.tipo = 'telefono'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtCompania'
        objParams.valor = $('#txtCompania').val() == undefined ? '' : $('#txtCompania').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtEmpresa'
        objParams.valor = $('#txtEmpresa').val() == undefined ? '' : $('#txtEmpresa').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtGiroEmpresa'
        objParams.valor = $('#txtGiroEmpresa').val() == undefined ? '' : $('#txtGiroEmpresa').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtPais'
        objParams.valor = $('#txtPais').val() == undefined ? '' : $('#txtPais').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtEstado'
        objParams.valor = $('#txtEstado').val() == undefined ? '' : $('#txtEstado').val()
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'txtCodigoPostal'
        objParams.valor = $('#txtCodigoPostal').val() == undefined ? '' : $('#txtCodigoPostal').val()
        objParams.requerido = true
        objParams.tipo = 'codigoPostal'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'chbxPrivacidad'
        objParams.valor = $('#chbxPrivacidad').val() == undefined ? '' : ($('#chbxPrivacidad').is(':checked') ? '1' : '')
        objParams.requerido = true
        objParams.tipo = 'texto'
        arrayParams.push(objParams)
        objParams = {}
        objParams.id = 'recaptcha'
        objParams.valor = $('#recaptcha').val() == undefined ? '' : $('#recaptcha').val()
        objParams.requerido = true
        objParams.tipo = 'recaptcha'
        arrayParams.push(objParams)
        objParams = {}

        var respCampos = validarCamposInput(arrayParams, 'submit')

        if (!respCampos.resp) {
            cerrarModalProcesando()
            var id = respCampos.id
            document.body.scrollTop = $('#' + id).offset().top
            if (id === 'recaptcha' && respCampos.error == 1) {
                $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Completa el CAPTCHA para continuar.')
                $('.alert-dismissible').addClass('alert-warning')
                $('.alert-dismissible').show()
                document.body.scrollTop = $('.alert-dismissible').offset().top
            } else if (id === 'chbxPrivacidad' && respCampos.error == 1) {
                $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Debe acepar el aviso de privacidad.')
                $('.alert-dismissible').addClass('alert-warning')
                $('.alert-dismissible').show()
                document.body.scrollTop = $('.alert-dismissible').offset().top
            }
            $('#' + id).tooltip('option', 'content', '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + dicInputsValidaciones.numError(respCampos.error));
            $('#' + id).tooltip("open")
            $('#' + id).focus()
            event.preventDefault()
        }
    } catch (err) {
        event.preventDefault()
        cerrarModalProcesando()
    }
}

function nuevaSesionAceptar() {
    try {
        limpiarAlert()
        abrirModalProcesando()

        $.ajax({
            url: $.path + 'Login/AceptarNuevaSesion',
            data: '',
            type: 'POST',
            dataType: 'JSON',
            contentType: false,
            processData: false,
            beforeSend: function () { },
            success: function (response) {
                console.log(response)
                if (response[0] == '0') {
                    $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Ha ocurrido algo inesperado<br />Intentar nuevamente o <a href="' + new URL(window.location.href) + '">refrescar página</a>')
                    $('.alert-dismissible').addClass('alert-danger')
                    $('.alert-dismissible').show()
                    cerrarModalProcesando()
                } else if (response[0] == '1') {
                    window.location.href = $.path + 'Main'
                } else if (response[0] == '2') {
                    $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Ha ocurrido algo inesperado<br />Intentar nuevamente o <a href="' + new URL(window.location.href) + '">refrescar página</a>')
                    $('.alert-dismissible').addClass('alert-danger')
                    $('.alert-dismissible').show()
                    cerrarModalProcesando()
                } else if (response[0] == '3') {
                    $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Ha ocurrido algo inesperado<br />Intentar nuevamente o <a href="' + new URL(window.location.href) + '">refrescar página</a>')
                    $('.alert-dismissible').addClass('alert-danger')
                    $('.alert-dismissible').show()
                    cerrarModalProcesando()
                }

            },
            error: function (response) {
                $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Ha ocurrido algo inesperado<br />Intentar nuevamente o <a href="' + new URL(window.location.href) + '">refrescar página</a>')
                $('.alert-dismissible').addClass('alert-danger')
                $('.alert-dismissible').show()
                cerrarModalProcesando()
            }
        })
    } catch (err) {
        $('.alert-txt').html('<i class="fa fa-warning fa-fw fa-lg"></i><strong> ¡Alerta!</strong> Ha ocurrido algo inesperado<br />Intentar nuevamente o <a href="' + new URL(window.location.href) + '">refrescar página</a>')
        $('.alert-dismissible').addClass('alert-danger')
        $('.alert-dismissible').show()
        cerrarModalProcesando()
    }
}

function nuevaSesionCancelar() {
    try {
        limpiarAlert()
        abrirModalProcesando()

        $.ajax({
            url: $.path + 'Login/CancelarNuevaSesion',
            data: '',
            type: 'POST',
            dataType: 'JSON',
            contentType: false,
            processData: false,
            beforeSend: function () { },
            success: function (response) {
                window.location.href = $.path + 'Login'
            },
            error: function (response) {
                cerrarModalProcesando()
            }
        })
    } catch (err) {
        cerrarModalProcesando()
    }
}



