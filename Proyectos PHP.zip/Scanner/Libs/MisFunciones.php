<?php

class MisFunciones {

    public static function quitaCaracteresEspeciales($respuesta) {
        $respuesta = str_replace("&", "&amp;", $respuesta);
        $respuesta = str_replace("#", "&#35;", $respuesta);
        $respuesta = str_replace("\\", "", $respuesta);
        $respuesta = str_replace("<", "&lt;", $respuesta);
        $respuesta = str_replace(">", "&gt;", $respuesta);
        $respuesta = str_replace('"', "&quot;", $respuesta);
        $respuesta = str_replace("!", "&#33;", $respuesta);
        $respuesta = str_replace("$", "&#36;", $respuesta);
        $respuesta = str_replace("%", "&#37;", $respuesta);
        $respuesta = str_replace("'", "&#39;", $respuesta);
        $respuesta = str_replace("(", "&#40;", $respuesta);
        $respuesta = str_replace(")", "&#41;", $respuesta);
        $respuesta = str_replace("*", "&#42;", $respuesta);
        $respuesta = str_replace("+", "&#43;", $respuesta);
        $respuesta = str_replace(",", "&#44;", $respuesta);
        $respuesta = str_replace("-", "&#45;", $respuesta);
        $respuesta = str_replace(".", "&#46;", $respuesta);
        $respuesta = str_replace("/", "&#47;", $respuesta);
        $respuesta = str_replace(":", "&#58;", $respuesta);
        $respuesta = str_replace("=", "&#61;", $respuesta);
        $respuesta = str_replace("?", "&#63;", $respuesta);
        $respuesta = str_replace("[", "&#91;", $respuesta);
        $respuesta = str_replace("[", "&#93;", $respuesta);
        $respuesta = str_replace("^", "&#94;", $respuesta);
        $respuesta = str_replace("_", "&#95;", $respuesta);
        $respuesta = str_replace("_", "&#95;", $respuesta);
        $respuesta = str_replace("{", "&#123;", $respuesta);
        $respuesta = str_replace("|", "&#124;", $respuesta);
        $respuesta = str_replace("}", "&#125;", $respuesta);
        $respuesta = str_replace("~", "&#126;", $respuesta);
        $respuesta = str_replace("¿", "&iquest;", $respuesta);
        $respuesta = str_replace("¡", "&iexcl;", $respuesta);
        return $respuesta;
    }

    public static function inversaCaracteresEspeciales($respuesta) {
        $respuesta = str_replace("&amp;", "&", $respuesta);
        $respuesta = str_replace("&#35;", "#", $respuesta);
        $respuesta = str_replace("&lt;", "<", $respuesta);
        $respuesta = str_replace("&gt;", ">", $respuesta);
        $respuesta = str_replace("&quot;", '"', $respuesta);
        $respuesta = str_replace("&#33;", "!", $respuesta);
        $respuesta = str_replace("&#36;", "$", $respuesta);
        $respuesta = str_replace("&#37;", "%", $respuesta);
        $respuesta = str_replace("&#39;", "'", $respuesta);
        $respuesta = str_replace("&#40;", "(", $respuesta);
        $respuesta = str_replace("&#41;", ")", $respuesta);
        $respuesta = str_replace("&#42;", "*", $respuesta);
        $respuesta = str_replace("&#43;", "+", $respuesta);
        $respuesta = str_replace("&#44;", ",", $respuesta);
        $respuesta = str_replace("&#45;", "-", $respuesta);
        $respuesta = str_replace("&#46;", ".", $respuesta);
        $respuesta = str_replace("&#47;", "/", $respuesta);
        $respuesta = str_replace("&#58;", ":", $respuesta);
        $respuesta = str_replace("&#61;", "=", $respuesta);
        $respuesta = str_replace("&#63;", "?", $respuesta);
        $respuesta = str_replace("&#91;", "[", $respuesta);
        $respuesta = str_replace("&#93;", "]", $respuesta);
        $respuesta = str_replace("&#94;", "^", $respuesta);
        $respuesta = str_replace("&#95;", "_", $respuesta);
        $respuesta = str_replace("&#123;", "{", $respuesta);
        $respuesta = str_replace("&#124;", "|", $respuesta);
        $respuesta = str_replace("&#125;", "}", $respuesta);
        $respuesta = str_replace("&#126;", "~", $respuesta);
        $respuesta = str_replace("&iquest;", "¿", $respuesta);
        $respuesta = str_replace("&iexcl;", "¡", $respuesta);
        return $respuesta;
    }

    public static function getIP() {
        $ip = NULL;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

    public static function getNavegador() {
        $navegador = NULL;
        $navegadorMatriz = get_browser(null, true);
        $navegador = 'parent: ' . $navegadorMatriz['parent'] . ' | browser_bits: ' . $navegadorMatriz['browser_bits'] . ' | comment: ' . $navegadorMatriz['comment'] . ' | browser: ' . $navegadorMatriz['browser'] . ' | browser_type: ' . $navegadorMatriz['browser_type'] . ' | browser_maker: ' . $navegadorMatriz['browser_maker'] . ' | version: ' . $navegadorMatriz['version'] . ' | majorver: ' . $navegadorMatriz['majorver'];
        return $navegador;
    }

    public static function getPlataforma() {
        $plataforma = NULL;

        $dispositivo = php_uname();
        $navegadorMatriz = get_browser(null, true);

        if (isset($dispositivo) && !empty($dispositivo)) {
            $plataforma = $dispositivo . ' ' . $navegadorMatriz['platform_bits'] . ' Bits';
        } else {
            $plataforma = 'platform: ' . $navegadorMatriz['platform'] . ' | platform_version: ' . $navegadorMatriz['platform_version'] . ' | platform_description: ' . $navegadorMatriz['platform_description'] . ' | platform_bits: ' . $navegadorMatriz['platform_bits'] . ' | platform_maker: ' . $navegadorMatriz['platform_maker'];
        }
        return $plataforma;
    }

    public static function getPCName() {
        $pcName = NULL;
        $aux = gethostname();
        if (isset($aux) && !empty($aux)) {
            $pcName = $aux;
        }
        return $pcName;
    }

    public static function getPCRed() {
        $dominioRed = NULL;
        $aux = gethostbyaddr(self::getIP());
        if (isset($aux) && !empty($aux)) {
            $dominioRed = $aux;
        }
        return $dominioRed;
    }

    public static function cerrarSesion() {
        if (isset($_SESSION['estadoTotalScanner']))
            unset($_SESSION['estadoTotalScanner']);
        if (isset($_SESSION['idSesionTotalScanner']))
            unset($_SESSION['idSesionTotalScanner']);
        if (isset($_SESSION['idUsuarioTotalScanner']))
            unset($_SESSION['idUsuarioTotalScanner']);
        if (isset($_SESSION['correoTotalScanner']))
            unset($_SESSION['correoTotalScanner']);
        if (isset($_SESSION['nombreTotalScanner']))
            unset($_SESSION['nombreTotalScanner']);
        if (isset($_SESSION['tiempoTotalScanner']))
            unset($_SESSION['tiempoTotalScanner']);
        if (isset($_SESSION['enviarCorreoTotalScanner']))
            unset($_SESSION['enviarCorreoTotalScanner']);
        if (isset($_SESSION['ipTotalScanner']))
            unset($_SESSION['ipTotalScanner']);
        if (isset($_SESSION['plataformaTotalScanner']))
            unset($_SESSION['plataformaTotalScanner']);
        if (isset($_SESSION['navegadorTotalScanner']))
            unset($_SESSION['navegadorTotalScanner']);
        if (isset($_SESSION['pcNameTotalScanner']))
            unset($_SESSION['pcNameTotalScanner']);
        if (isset($_SESSION['pcRedTotalScanner']))
            unset($_SESSION['pcRedTotalScanner']);
        if (isset($_SESSION['respuestaAccesosTotalScanner']))
            unset($_SESSION['respuestaAccesosTotalScanner']);
        if (isset($_SESSION['intentosAccesoTotalScanner']))
            unset($_SESSION['intentosAccesoTotalScanner']);
        if (isset($_SESSION['idPerfilTotalScanner']))
            unset($_SESSION['idPerfilTotalScanner']);
    }

}
