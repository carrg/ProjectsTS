<?php

class DB {

    public static $conn;

    function __construct() {
        try {
            $serverName = '10.67.153.43';
            $connectionInfo = array('Database' => 'TotalScanner', 'UID' => 'DTs9090', 'PWD' => 'D45b04rdT0t4153c');
            self::$conn = sqlsrv_connect($serverName, $connectionInfo);
        } catch (Exception $ex) {
            self::$conn = NULL;
        }
    }

    public function registrarError($tipo, $error, $archivo, $linea, $context, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $stmt = NULL;
        try {
            if (self::$conn) {
                if (sqlsrv_begin_transaction(self::$conn)) {

                    $params = array(
                        array($tipo, SQLSRV_PARAM_IN),
                        array($error, SQLSRV_PARAM_IN),
                        array($archivo, SQLSRV_PARAM_IN),
                        array($linea, SQLSRV_PARAM_IN),
                        array($idUsuario, SQLSRV_PARAM_IN),
                        array($ip, SQLSRV_PARAM_IN),
                        array($plataforma, SQLSRV_PARAM_IN),
                        array($navegador, SQLSRV_PARAM_IN),
                        array($pcName, SQLSRV_PARAM_IN),
                        array($pcRed, SQLSRV_PARAM_IN)
                    );

                    $stmt = sqlsrv_query(self::$conn, '{call dbo.registrarError(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}', $params);

                    if ($stmt) {
                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(self::$conn);
                        sqlsrv_close(self::$conn);
                        self::$conn = NULL;
                    }
                } else {
                    sqlsrv_close(self::$conn);
                    self::$conn = NULL;
                }
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(self::$conn);
            sqlsrv_close(self::$conn);
            self::$conn = NULL;
        }
    }

    public function validarSesionDB($idUsuario, $idSesion, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $respuesta = null;
        $stmt = NULL;
        try {
            if (self::$conn) {

                if (sqlsrv_begin_transaction(self::$conn)) {

                    $params = array(
                        array($idUsuario, SQLSRV_PARAM_IN),
                        array($idSesion, SQLSRV_PARAM_IN),
                        array($ip, SQLSRV_PARAM_IN),
                        array($navegador, SQLSRV_PARAM_IN),
                        array($plataforma, SQLSRV_PARAM_IN)
                    );
                    $stmt = sqlsrv_query(self::$conn, '{call dbo.validarSesion(?, ?, ?, ?, ?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {
                            // SQLSRV_FETCH_NUMERIC
                            // SQLSRV_FETCH_ASSOC
                            $respuesta = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC)[0];
                        } else
                            $respuesta = '0';

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(self::$conn);
                        sqlsrv_close(self::$conn);
                        self::$conn = NULL;
                    } else 
                        throw new Exception(sqlsrv_errors()[0]['message']);
                } else {
                    sqlsrv_close(self::$conn);
                    self::$conn = NULL;
                    $respuesta = '0';
                }
            } else {
                $respuesta = '0';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(self::$conn);
            
            self::registrarError(3, $ex->getMessage(), $ex->getFile(), $ex->getLine(), NULL, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed);

            $respuesta = '0';
        }

        return $respuesta;
    }

    public function validarNavegacion($idPerfil, $controlador, $metodo, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $respuesta = null;
        $stmt = NULL;
        try {
            if (self::$conn) {

                if (sqlsrv_begin_transaction(self::$conn)) {

                    $params = array(
                        array($idPerfil, SQLSRV_PARAM_IN),
                        array($controlador, SQLSRV_PARAM_IN),
                        array($metodo, SQLSRV_PARAM_IN)
                    );
                    $stmt = sqlsrv_query(self::$conn, '{call dbo.validarNavegacion(?, ?, ?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {
                            // SQLSRV_FETCH_NUMERIC
                            // SQLSRV_FETCH_ASSOC
                            $respuesta = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC)[0];
                        } else
                            $respuesta = '0';

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(self::$conn);
                        sqlsrv_close(self::$conn);
                        self::$conn = NULL;
                    } else
                        throw new Exception(sqlsrv_errors()[0]['message']);
                } else {
                    sqlsrv_close(self::$conn);
                    self::$conn = NULL;
                    $respuesta = '2';
                }
            } else {
                $respuesta = '2';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(self::$conn);

            self::registrarError(3, $ex->getMessage(), $ex->getFile(), $ex->getLine(), NULL, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed);

            $respuesta = '2';
        }

        return $respuesta;
    }

    // Ésta es una prueba
    public function testCaracteresDB($texto, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $stmt = NULL;
        try {
            if (self::$conn) {

                if (sqlsrv_begin_transaction(self::$conn)) {

                    $params = array(
                        array($texto, SQLSRV_PARAM_IN)
                    );

                    $stmt = sqlsrv_query(self::$conn, '{call dbo.testCaracteress(?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {

                            print_r(sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC));
                        } else
                            echo 'Vacio';

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(self::$conn);
                        sqlsrv_close(self::$conn);
                        self::$conn = NULL;
                    } else
                        throw new Exception(sqlsrv_errors()[0]['message']);
                } else {
                    sqlsrv_close(self::$conn);
                    self::$conn = NULL;

                    echo 'Error no transacción';
                }
            } else {
                echo 'Error no conexión';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(self::$conn);

            self::registrarError(3, $ex->getMessage(), $ex->getFile(), $ex->getLine(), NULL, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed);
        }
    }

}
