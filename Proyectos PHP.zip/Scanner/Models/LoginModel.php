<?php

class LoginModel extends DB {

    function __construct() {
        parent::__construct();
    }

    public function RegistrosIP($ip) {
        $respuesta = null;
        $stmt = NULL;
        try {
            if (parent::$conn) {

                if (sqlsrv_begin_transaction(parent::$conn)) {

                    $params = array(
                        array($ip, SQLSRV_PARAM_IN)
                    );
                    $stmt = sqlsrv_query(parent::$conn, '{call dbo.registrosIP(?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {
                            // SQLSRV_FETCH_NUMERIC
                            // SQLSRV_FETCH_ASSOC
                            $respuesta = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC)[0];
                        } else
                            $respuesta = '1';

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(parent::$conn);
                        sqlsrv_close(parent::$conn);
                        parent::$conn = NULL;
                    } else {
                        if ($stmt)
                            sqlsrv_free_stmt($stmt);
                        sqlsrv_rollback(parent::$conn);
                        sqlsrv_close(parent::$conn);
                        parent::$conn = NULL;

                        $respuesta = '1';
                    }
                } else {
                    sqlsrv_close(parent::$conn);
                    parent::$conn = NULL;
                    $respuesta = '1';
                }
            } else {
                $respuesta = '12';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(parent::$conn);
            sqlsrv_close(parent::$conn);
            parent::$conn = NULL;

            $respuesta = '1';
        }

        return $respuesta;
    }

    public function validarAccesosDB($usuario, $contrasena, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $respuesta = null;
        $stmt = NULL;
        try {
            if (parent::$conn) {

                if (sqlsrv_begin_transaction(parent::$conn)) {

                    $params = array(
                        array(1, SQLSRV_PARAM_IN),
                        array($usuario, SQLSRV_PARAM_IN),
                        array($contrasena, SQLSRV_PARAM_IN),
                        array($ip, SQLSRV_PARAM_IN),
                        array($navegador, SQLSRV_PARAM_IN),
                        array($plataforma, SQLSRV_PARAM_IN),
                        array($pcName, SQLSRV_PARAM_IN),
                        array('', SQLSRV_PARAM_IN),
                        array('', SQLSRV_PARAM_IN),
                        array($pcRed, SQLSRV_PARAM_IN)
                    );
                    $stmt = sqlsrv_query(parent::$conn, '{call dbo.validarAcceso(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {
                            // SQLSRV_FETCH_NUMERIC
                            // SQLSRV_FETCH_ASSOC
                            $respuesta = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC);
                        } else
                            $respuesta[0] = '1';

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(parent::$conn);
                        sqlsrv_close(parent::$conn);
                        parent::$conn = NULL;
                    } else
                        throw new Exception(sqlsrv_errors()[0]['message']);
                } else {
                    sqlsrv_close(parent::$conn);
                    parent::$conn = NULL;
                    $respuesta[0] = '1';
                }
            } else {
                $respuesta[0] = '12';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(parent::$conn);

            parent::registrarError(3, $ex->getMessage(), $ex->getFile(), $ex->getLine(), NULL, 0, $ip, $plataforma, $navegador, $pcName, $pcRed);

            $respuesta[0] = '1';
        }

        return $respuesta;
    }

    public function nuevaSesion($idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $respuesta = null;
        $stmt = NULL;
        try {
            if (parent::$conn) {

                if (sqlsrv_begin_transaction(parent::$conn)) {

                    $params = array(
                        array($idUsuario, SQLSRV_PARAM_IN),
                        array($ip, SQLSRV_PARAM_IN),
                        array($navegador, SQLSRV_PARAM_IN),
                        array($plataforma, SQLSRV_PARAM_IN),
                        array($pcName, SQLSRV_PARAM_IN),
                        array($pcRed, SQLSRV_PARAM_IN)
                    );
                    $stmt = sqlsrv_query(parent::$conn, '{call dbo.nuevaSesion(?, ?, ?, ?, ?, ?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {
                            // SQLSRV_FETCH_NUMERIC
                            // SQLSRV_FETCH_ASSOC
                            $respuesta = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC);
                        } else
                            $respuesta[0] = '0';

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(parent::$conn);
                        sqlsrv_close(parent::$conn);
                        parent::$conn = NULL;
                    } else
                        throw new Exception(sqlsrv_errors()[0]['message']);
                } else {
                    sqlsrv_close(parent::$conn);
                    parent::$conn = NULL;
                    $respuesta[0] = '0';
                }
            } else {
                $respuesta[0] = '2';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(parent::$conn);

            parent::registrarError(3, $ex->getMessage(), $ex->getFile(), $ex->getLine(), NULL, $idUsuario, $ip, $plataforma, $navegador, $pcName, $pcRed);

            $respuesta[0] = '0';
        }

        return $respuesta;
    }

    public function registrarUsuarioDB($nombres, $apellido, $correo, $telefono, $celular, $companiaCel, $nombreEmpresa, $giroEmpresa, $pais, $estado, $codigoPostal, $ip, $plataforma, $navegador, $pcName, $pcRed) {
        $respuesta = null;
        $stmt = NULL;
        try {
            if (parent::$conn) {

                if (sqlsrv_begin_transaction(parent::$conn)) {

                    $params = array(
                        array($nombres, SQLSRV_PARAM_IN),
                        array($apellido, SQLSRV_PARAM_IN),
                        array($correo, SQLSRV_PARAM_IN),
                        array($telefono, SQLSRV_PARAM_IN),
                        array($celular, SQLSRV_PARAM_IN),
                        array($companiaCel, SQLSRV_PARAM_IN),
                        array($nombreEmpresa, SQLSRV_PARAM_IN),
                        array($giroEmpresa, SQLSRV_PARAM_IN),
                        array($pais, SQLSRV_PARAM_IN),
                        array($estado, SQLSRV_PARAM_IN),
                        array($codigoPostal, SQLSRV_PARAM_IN),
                        array($ip, SQLSRV_PARAM_IN),
                        array($navegador, SQLSRV_PARAM_IN),
                        array($plataforma, SQLSRV_PARAM_IN),
                        array($pcName, SQLSRV_PARAM_IN),
                        array($pcRed, SQLSRV_PARAM_IN)
                    );
                    $stmt = sqlsrv_query(parent::$conn, '{call dbo.registrarUsuario(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}', $params);

                    if ($stmt) {
                        if (sqlsrv_has_rows($stmt)) {
                            // SQLSRV_FETCH_NUMERIC
                            // SQLSRV_FETCH_ASSOC
                            $respuesta = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC);
                        } else {
                            $mensaje = 'No se pudo realizar el registro del usuario';
                            $archivo = 'Archivo: LoginModel.php - Metodo: registrarUsuarioDB';
                            $linea = __LINE__;
                            parent::registrarError(3, $mensaje, $archivo, $linea, NULL, 0, $ip, $plataforma, $navegador, $pcName, $pcRed);

                            $respuesta[0] = '0';
                        }

                        sqlsrv_free_stmt($stmt);
                        sqlsrv_commit(parent::$conn);
                        sqlsrv_close(parent::$conn);
                        parent::$conn = NULL;
                    } else
                        throw new Exception(sqlsrv_errors()[0]['message']);
                } else {
                    sqlsrv_close(parent::$conn);
                    parent::$conn = NULL;

                    $mensaje = 'No se pudo iniciar la transacción';
                    $archivo = 'Archivo: LoginModel.php - Metodo: registrarUsuarioDB';
                    $linea = __LINE__;
                    parent::registrarError(3, $mensaje, $archivo, $linea, NULL, 0, $ip, $plataforma, $navegador, $pcName, $pcRed);

                    $respuesta[0] = '0';
                }
            } else {
                $mensaje = 'No existe conexión con la base de datos';
                $archivo = 'Archivo: LoginModel.php - Metodo: registrarUsuarioDB';
                $linea = __LINE__;
                parent::registrarError(3, $mensaje, $archivo, $linea, NULL, 0, $ip, $plataforma, $navegador, $pcName, $pcRed);

                $respuesta[0] = '0';
            }
        } catch (Exception $ex) {
            if ($stmt)
                sqlsrv_free_stmt($stmt);
            sqlsrv_rollback(parent::$conn);

            parent::registrarError(3, $ex->getMessage(), $ex->getFile(), $ex->getLine(), NULL, 0, $ip, $plataforma, $navegador, $pcName, $pcRed);

            $respuesta[0] = '0';
        }

        return $respuesta;
    }

}

?>
