<?php

class MainController {

    private $controlador;
    private $metodo;
    private $ip;
    private $plataforma;
    private $navegador;
    private $pcName;
    private $pcRed;

    function __construct($controlador, $metodo) {
        $this->controlador = $controlador;
        $this->metodo = $metodo;
        $this->ip = MisFunciones::getIP();
        $this->plataforma = MisFunciones::getPlataforma();
        $this->navegador = MisFunciones::getNavegador();
        $this->pcName = MisFunciones::getPCName();
        $this->pcRed = MisFunciones::getPCRed();
    }

    public function Index() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'GET') {
            date_default_timezone_set('America/Mexico_City');

            if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'nueva')
                header('Location: ' . DIRECTORIOWEB . 'Login/NewSession');
            else if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'activa') {
                if (call_user_func([new LoginModel(), 'validarSesionDB'], $_SESSION['idUsuarioTotalScanner'], $_SESSION['idSesionTotalScanner'], $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed) == 1) {
                    $_SESSION['tiempoTotalScanner'] = 0;
                    $respuestaNavegacion = call_user_func([new LoginModel(), 'validarNavegacion'], $_SESSION['idPerfilTotalScanner'], $this->controlador, $this->metodo, $_SESSION['idUsuarioTotalScanner'], $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed);
                    if ($respuestaNavegacion == 0) {
                        echo 'No tienes permiso de estar aquí';
                    } else if ($respuestaNavegacion == 1) {
                        $viewParametro = 'Parametro enviado';
                        require 'Views/' . $this->controlador . '/' . $this->metodo . '.php';
                    } else if ($respuestaNavegacion == 2) {
                        echo 'Ha ocurrido algo inesperado';
                    } else {
                        echo 'Ha ocurrido algo inesperado';
                    }
                } else {
                    MisFunciones::cerrarSesion();
                    $_SESSION['respuestaAccesosTotalScanner'] = 11;
                    header('Location: ' . DIRECTORIOWEB . 'Login');
                }
            } else {
                MisFunciones::cerrarSesion();
                $_SESSION['respuestaAccesosTotalScanner'] = 11;
                header('Location: ' . DIRECTORIOWEB . 'Login');
            }
        } else
            header('Location: ' . DIRECTORIOWEB . 'Main');
    }

}
