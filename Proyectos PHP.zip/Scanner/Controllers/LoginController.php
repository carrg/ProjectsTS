<?php

class LoginController {

    private $controlador;
    private $metodo;
    private $ip;
    private $plataforma;
    private $navegador;
    private $pcName;
    private $pcRed;

    function __construct($controlador, $metodo) {
        $this->controlador = $controlador;
        $this->metodo = $metodo;
        $this->ip = MisFunciones::getIP();
        $this->plataforma = MisFunciones::getPlataforma();
        $this->navegador = MisFunciones::getNavegador();
        $this->pcName = MisFunciones::getPCName();
        $this->pcRed = MisFunciones::getPCRed();

        // call_user_func([new LoginModel(), 'testCaracteresDB'], MisFunciones::quitaCaracteresEspeciales('isc.carrgtest@gmail.com'), isset($_SESSION['idUsuarioTotalScanner']) ? $_SESSION['idUsuarioTotalScanner'] : 0, $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed);
    }

    public function Index() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'GET') {
            date_default_timezone_set('America/Mexico_City');

            $vistaAlerta = NULL;
            $vistaTextoAlerta = NULL;
            $vistaClaseAlerta = NULL;
            $vistaHiddenAlerta = NULL;

            if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'nueva')
                header('Location: ' . DIRECTORIOWEB . 'Login/NewSession');
            else if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'activa') {
                if (call_user_func([new LoginModel(), 'validarSesionDB'], $_SESSION['idUsuarioTotalScanner'], $_SESSION['idSesionTotalScanner'], $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed) == 1) {
                    header('Location: ' . DIRECTORIOWEB . 'Main');
                } else {
                    MisFunciones::cerrarSesion();
                }
            } else {
                if (isset($_SESSION) && isset($_SESSION['respuestaAccesosTotalScanner'])) {
                    $respuesta = $_SESSION['respuestaAccesosTotalScanner'];
                    $vistaHiddenAlerta = 'false';

                    switch ($respuesta) {
                        case "1":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> Ha ocurrido algo inesperado, favor de intentar nuevamente";
                            break;
                        case "2":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> No se pudo establecer conexión con llave maestra, favor de intentarlo nuevamente";
                            break;
                        case "3":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-times-circle fa-fw fa-lg'></i> <strong>¡Error!</strong> Los datos introducidos no cuentan con los parametros";
                            break;
                        case "4":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-times-circle fa-fw fa-lg'></i> <strong>¡Error!</strong> Usuario o contraseña incorrectos";
                            break;
                        case "5":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> El usuario ha sido dado de baja";
                            break;
                        case "6":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> El usuario ha sido cancelado por inactividad<br />Favor de comunicarse con el administrador";
                            break;
                        case "7":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-times-circle fa-fw fa-lg'></i> <strong>¡Error!</strong> Usuario o contraseña incorrectos";
                            break;
                        case "8":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> El usuario ha sido bloqueado temporalmente<br />Debe esperar al menos 10 mins";
                            break;
                        case "11":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> Es necesario iniciar sesión";
                            break;
                        case "12":
                            $vistaClaseAlerta = 'alert-danger';
                            $vistaAlerta = "<i class='fa fa-warning fa-fw fa-lg'></i> <strong>¡Alerta!</strong> No se pudo estableces conexión con la Base de Datos";
                            break;
                    }
                }
                MisFunciones::cerrarSesion();
            }
            require 'Views/' . $this->controlador . '/' . $this->metodo . '.php';
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login');
    }

    public function Register() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'GET') {
            date_default_timezone_set('America/Mexico_City');

            $vistaAlerta = NULL;
            $vistaTextoAlerta = NULL;
            $vistaClaseAlerta = NULL;
            $vistaHiddenAlerta = NULL;

            $respuestaDB = call_user_func([new LoginModel(), 'RegistrosIP'], $this->ip);

            if ($respuestaDB > 10)
                require 'Views/' . $this->controlador . '/LimitIP.php';
            else
                require 'Views/' . $this->controlador . '/' . $this->metodo . '.php';
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login/Register');
    }

    public function ValidateAccess() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'POST') {
            date_default_timezone_set('America/Mexico_City');

            $recaptcha = filter_input(INPUT_POST, 'recaptcha');
            if (isset($recaptcha) && !empty($recaptcha))
                $CarRG = filter_input(INPUT_POST, 'recaptcha');
            else
                $CarRG = CARRG;

            $correo = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtUsuario')), $CarRG));
            $contrasena = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtContrasena')), $CarRG));

            if (filter_var($correo, FILTER_VALIDATE_EMAIL)) {

                /* $correo = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($correo))));
                  $contrasena = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($contrasena)))); */

                $correo = addslashes(htmlentities(strip_tags($correo)));
                $contrasena = addslashes(htmlentities(strip_tags($contrasena)));

                $respuestaDB = call_user_func([new LoginModel(), 'validarAccesosDB'], $correo, $contrasena, $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed);

                if ($respuestaDB[0] == '1') {
                    $_SESSION['respuestaAccesosTotalScanner'] = $respuestaDB[0];
                    header('Location: ' . DIRECTORIOWEB . 'Login');
                } else if ($respuestaDB[0] == '4') {
                    $_SESSION['respuestaAccesosTotalScanner'] = $respuestaDB[0];
                    $_SESSION['intentosAccesoTotalScanner'] = $respuestaDB[4];
                    header('Location: ' . DIRECTORIOWEB . 'Login');
                } else if ($respuestaDB[0] == '7') {
                    $_SESSION['respuestaAccesosTotalScanner'] = $respuestaDB[0];
                    $_SESSION['intentosAccesoTotalScanner'] = $respuestaDB[3];
                    header('Location: ' . DIRECTORIOWEB . 'Login');
                } else if ($respuestaDB[0] == '9') {
                    header('Location: ' . DIRECTORIOWEB . 'Login/BlockingIP');
                } else if ($respuestaDB[0] == '10') {
                    $_SESSION['estadoTotalScanner'] = 'nueva';
                    $_SESSION['idSesionTotalScanner'] = $respuestaDB[5];
                    $_SESSION['idUsuarioTotalScanner'] = $respuestaDB[6];
                    $_SESSION['idPerfilTotalScanner'] = $respuestaDB[7];
                    $_SESSION['correoTotalScanner'] = $respuestaDB[2];
                    $_SESSION['nombreTotalScanner'] = $respuestaDB[1];
                    $_SESSION['tiempoTotalScanner'] = 0;

                    $_SESSION['ipTotalScanner'] = $this->ip;
                    $_SESSION['plataformaTotalScanner'] = $this->plataforma;
                    $_SESSION['navegadorTotalScanner'] = $this->navegador;
                    $_SESSION['pcNameTotalScanner'] = $this->pcName;
                    $_SESSION['pcRedTotalScanner'] = $this->pcRed;

                    header('Location: ' . DIRECTORIOWEB . 'Login/NewSession');
                } else if ($respuestaDB[0] == '100') {
                    $_SESSION['estadoTotalScanner'] = 'activa';
                    $_SESSION['idSesionTotalScanner'] = $respuestaDB[5];
                    $_SESSION['idUsuarioTotalScanner'] = $respuestaDB[6];
                    $_SESSION['idPerfilTotalScanner'] = $respuestaDB[7];
                    $_SESSION['correoTotalScanner'] = $respuestaDB[2];
                    $_SESSION['nombreTotalScanner'] = $respuestaDB[1];
                    $_SESSION['tiempoTotalScanner'] = 0;
                    $_SESSION['enviarCorreoTotalScanner'] = 1;
                    header('Location: ' . DIRECTORIOWEB . 'Main');
                } else {
                    $_SESSION['respuestaAccesosTotalScanner'] = $respuestaDB[0];
                    header('Location: ' . DIRECTORIOWEB . 'Login');
                }
            } else {
                $_SESSION['respuestaAccesos'] = '3';
                header('Location: ' . DIRECTORIOWEB . 'Login');
            }
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login');
    }

    public function ValidateRegister() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'POST') {
            date_default_timezone_set('America/Mexico_City');

            $recaptcha = filter_input(INPUT_POST, 'recaptcha');
            if (isset($recaptcha) && !empty($recaptcha))
                $CarRG = filter_input(INPUT_POST, 'recaptcha');
            else
                $CarRG = CARRG;

            $nombres = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtNombre')), $CarRG));
            $apellido = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtAPaterno')), $CarRG));
            $correo = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtCorreo')), $CarRG));
            $telefono = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtTelefono')), $CarRG));
            $celular = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtCelular')), $CarRG));
            $companiaCel = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtCompania')), $CarRG));
            $nombreEmpresa = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtEmpresa')), $CarRG));
            $giroEmpresa = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtGiroEmpresa')), $CarRG));
            $pais = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtPais')), $CarRG));
            $estado = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtEstado')), $CarRG));
            $codigoPostal = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'txtCodigoPostal')), $CarRG));
            $privacidad = MisFunciones::inversaCaracteresEspeciales(Crypt::decrypt(trim(filter_input(INPUT_POST, 'chbxPrivacidad')), $CarRG));

            $nombres = filter_var($nombres, FILTER_SANITIZE_STRING);
            $apellido = filter_var($apellido, FILTER_SANITIZE_STRING);
            $correo = filter_var($correo, FILTER_SANITIZE_EMAIL);
            $telefono = filter_var($telefono, FILTER_SANITIZE_NUMBER_INT);
            $celular = filter_var($celular, FILTER_SANITIZE_NUMBER_INT);
            $companiaCel = filter_var($companiaCel, FILTER_SANITIZE_STRING);
            $nombreEmpresa = filter_var($nombreEmpresa, FILTER_SANITIZE_STRING);
            $giroEmpresa = filter_var($giroEmpresa, FILTER_SANITIZE_STRING);
            $pais = filter_var($pais, FILTER_SANITIZE_STRING);
            $estado = filter_var($estado, FILTER_SANITIZE_STRING);
            $codigoPostal = filter_var($codigoPostal, FILTER_SANITIZE_NUMBER_INT);
            $privacidad = filter_var($privacidad, FILTER_SANITIZE_STRING);

            if (isset($nombres) && !empty($nombres) && isset($apellido) && !empty($apellido) && isset($correo) && !empty($correo) && filter_var($correo, FILTER_VALIDATE_EMAIL) && isset($telefono) && !empty($telefono) && is_numeric($telefono) && isset($celular) && !empty($celular) && is_numeric($celular) && isset($companiaCel) && !empty($companiaCel) && isset($giroEmpresa) && !empty($giroEmpresa) && isset($pais) && !empty($pais) && isset($estado) && !empty($estado) && isset($codigoPostal) && !empty($codigoPostal) && is_numeric($codigoPostal) && isset($privacidad) && !empty($privacidad)) {
                $nombres = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($nombres))));
                $apellido = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($apellido))));
                $correo = addslashes(htmlentities(strip_tags($correo)));
                $telefono = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($telefono))));
                $celular = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($celular))));
                $companiaCel = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($companiaCel))));
                $nombreEmpresa = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($nombreEmpresa))));
                $giroEmpresa = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($giroEmpresa))));
                $pais = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($pais))));
                $estado = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($estado))));
                $codigoPostal = addslashes(htmlentities(strip_tags(MisFunciones::quitaCaracteresEspeciales($codigoPostal))));
                
                $respuestaDB = call_user_func([new LoginModel(), 'registrarUsuarioDB'], $nombres, $apellido, $correo, $telefono, $celular, $companiaCel, $nombreEmpresa, $giroEmpresa, $pais, $estado, $codigoPostal, $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed);
                
                print_r($respuestaDB);
                
            } else {
                echo 'Something is wrong';
            }

            // header('Location: ' . DIRECTORIOWEB . 'Login/ConfirmRegister');
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login/Register');
    }

    public function ConfirmRegister() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'GET') {
            date_default_timezone_set('America/Mexico_City');

            require 'Views/' . $this->controlador . '/' . $this->metodo . '.php';
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login/ConfirmRegister');
    }

    public function NewSession() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'GET') {
            date_default_timezone_set('America/Mexico_City');

            if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'activa') {
                if (call_user_func([new LoginModel(), 'validarSesionDB'], $_SESSION['idUsuarioTotalScanner'], $_SESSION['idSesionTotalScanner'], $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed) == 1) {
                    header('Location: ' . DIRECTORIOWEB . 'Main');
                } else {
                    MisFunciones::cerrarSesion();
                    $_SESSION['respuestaAccesosTotalScanner'] = 11;
                    header('Location: ' . DIRECTORIOWEB . 'Login');
                }
            } else if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'nueva' && isset($_SESSION['ipTotalScanner']) && isset($_SESSION['plataformaTotalScanner']) && isset($_SESSION['navegadorTotalScanner']) && isset($_SESSION['pcNameTotalScanner']) && isset($_SESSION['pcRedTotalScanner']) && $_SESSION['ipTotalScanner'] == $this->ip && $_SESSION['plataformaTotalScanner'] == $this->plataforma && $_SESSION['navegadorTotalScanner'] == $this->navegador && $_SESSION['pcNameTotalScanner'] == $this->pcName && $_SESSION['pcRedTotalScanner'] == $this->pcRed) {
                $_SESSION['tiempoTotalScanner'] = 0;
                require 'Views/' . $this->controlador . '/' . $this->metodo . '.php';
            } else {
                MisFunciones::cerrarSesion();
                $_SESSION['respuestaAccesosTotalScanner'] = 11;
                header('Location: ' . DIRECTORIOWEB . 'Login');
            }
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login/NewSession');
    }

    public function AceptarNuevaSesion() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'POST') {
            date_default_timezone_set('America/Mexico_City');

            $respuesta = NULL;

            if (isset($_SESSION) && isset($_SESSION['estadoTotalScanner']) && $_SESSION['estadoTotalScanner'] == 'nueva' && isset($_SESSION['ipTotalScanner']) && isset($_SESSION['plataformaTotalScanner']) && isset($_SESSION['navegadorTotalScanner']) && isset($_SESSION['pcNameTotalScanner']) && isset($_SESSION['pcRedTotalScanner']) && $_SESSION['ipTotalScanner'] == $this->ip && $_SESSION['plataformaTotalScanner'] == $this->plataforma && $_SESSION['navegadorTotalScanner'] == $this->navegador && $_SESSION['pcNameTotalScanner'] == $this->pcName && $_SESSION['pcRedTotalScanner'] == $this->pcRed) {

                $respuesta = call_user_func([new LoginModel(), 'nuevaSesion'], $_SESSION['idUsuarioTotalScanner'], $this->ip, $this->plataforma, $this->navegador, $this->pcName, $this->pcRed);
                if ($respuesta[0] == 1 || $respuesta[0] == '1') {
                    $_SESSION['estadoTotalScanner'] = 'activa';
                    $_SESSION['idSesionTotalScanner'] = $respuesta[1];
                    $_SESSION['tiempoTotalScanner'] = 0;
                    $_SESSION['enviarCorreoTotalScanner'] = 1;
                }
            } else {
                $respuesta[0] = '3';
            }
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login');
        die(json_encode($respuesta));
    }

    public function CancelarNuevaSesion() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'POST') {
            date_default_timezone_set('America/Mexico_City');
            MisFunciones::cerrarSesion();
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login');
        die(json_encode(array('' => '')));
    }

    public function CerrarSesion() {
        $request = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        if (isset($request) && !empty($request) && is_string($request) && $request === 'POST') {
            date_default_timezone_set('America/Mexico_City');

            MisFunciones::cerrarSesion();
        } else
            header('Location: ' . DIRECTORIOWEB . 'Login');
        die(json_encode(array('' => '')));
    }

}
?>

