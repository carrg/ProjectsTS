<?php
    echo "<pre>";

    use Firebase\JWT\JWT;

    require_once "JWT.php";

    $time = time();
    $key = "mtyeFiRyFvo4JUc54s0JEqt6GWVQqKOZ";
    
    /*$token = array(
        "username" => "CarRG",
        "password" => "180818",
        "iat" => $time, // Tiempo que inicia el token
        "exp" => $time + (60 * 30) // Tiempo que expir el token, 30 minutos
    );*/

    /*{
      "user_metadata": {
          "login": "",
          "password": ""
        }
    }*/

    $token = '
      {
        "user_metadata": 
          {
            "login": "CarRG",
            "password": "180818"
          }
      }
    ';

    $jwtData =JWT::encode($token, $key);

    $curl = curl_init();

    curl_setopt($curl, CURLOPT_URL, "http://localhost:3000/v1/users/singin");
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST"); 
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            //"Content-length: 0",
            "Content-Type: application/json",
            "Authorization: Bearer " . $jwtData 
        )
    );

    //curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    //curl_setopt($curl, CURLOPT_USERPWD, "username:password");
    //curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //curl_setopt($curl, CURLOPT_POST, 1);
    //curl_setopt($curl, CURLOPT_PUT, 1);
    //curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
    //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST"); 
    //curl_setopt($crl, CURLOPT_SSL_VERIFYHOST, false);
    //curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);

    // Datos que van en el body, por ejemplo al dar de alta un usuario
    /*curl_setopt($curl, CURLOPT_POSTFIELDS, 
        '
            {
                "name": "Carmelo",
                "last_name": "Rodriguez",
                "phone": "7774412104"	
            }
        '
    );*/

    $jwtResp = curl_exec($curl);
    $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

    if ($jwtResp === false)
    {
        // throw new Exception('Curl error: ' . curl_error($crl));
        print_r('Curl error: ' . curl_error($curl));
    } 
    else
    {
      if ($httpcode == 200)
      {
        $respData = JWT::decode($jwtResp, $key, array("HS256"));
        //print_r($respData -> name);
        print_r($respData);
      }
      else
      {
        echo "El usuario no existe";
      }
    }

    curl_close($curl);

    echo "</pre>"; 
?>


<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAT3SeacVjILqz0Jqhl8YrlYz2Cxxy09PI&signed_in=true"></script>
<input id="latlng" type="text" value="-34.653015, -58.674850">
<input id="submit" type="button" value="Obtenr Nombre">
<div id="map"></div>
<script>
  initMap();

function initMap() {
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 8,
    center: {
      lat: -34.653015,
      lng: -58.674850
    }
  });
  var geocoder = new google.maps.Geocoder;
  var infowindow = new google.maps.InfoWindow;

  document.getElementById('submit').addEventListener('click', function() {
    geocodeLatLng(geocoder, map, infowindow);
  });
}

function geocodeLatLng(geocoder, map, infowindow) {
  var input = document.getElementById('latlng').value;
  var latlngStr = input.split(',', 2);
  var latlng = {
    lat: parseFloat(latlngStr[0]),
    lng: parseFloat(latlngStr[1])
  };
  geocoder.geocode({
    'location': latlng
  }, function(results, status) {
    if (status === google.maps.GeocoderStatus.OK) {
      if (results[1]) {
        map.setZoom(11);
        var marker = new google.maps.Marker({
          position: latlng,
          map: map
        });
        infowindow.setContent(results[1].formatted_address);
        infowindow.open(map, marker);
      } else {
        window.alert('No hay resultados');
      }
    } else {
      window.alert('Geocoder failed due to: ' + status);
    }
  });
}
</script> -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
    /* Obtiene información de la IP */
    $.get("http://ipinfo.io", function (response) {
        console.log(response)
    }, "jsonp");

    /* Obetiene información pasando GEO */
    latitud = "19.432608";
    longitud = "-99.133209";
    $.ajax({
        dataType: "json",
        url: "http://nominatim.openstreetmap.org/reverse",
        type: "get",
        data: {format: "json", lat:latitud, lon:longitud}
    }).done(function(data) {
        console.log(data)
        // ciudad = data.address.city;
    });
</script>

