﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolarWindsNOC.Models
{
    class DatosClientes
    {
        public string Cliente { get; set; } = string.Empty;
        public string NodeName { get; set; } = string.Empty;
        public string IP_Address { get; set; } = string.Empty;
        public decimal CPULoad { get; set; }
        public decimal PercentMemoryUsed { get; set; }
        public string Contacto { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public string StatusDescription { get; set; } = string.Empty;
        public string Brand { get; set; } = string.Empty;
        public string Estado { get; set; } = string.Empty;
        public string Latitude { get; set; } = string.Empty;
        public string Longitude { get; set; } = string.Empty;
    }
}
