﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SolarWindsNOC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SolarWindsNOC
{
    class Program
    {
        static void Main(string[] args)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(delegate { return true; });
            ServicePointManager.ServerCertificateValidationCallback += delegate (
                object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                System.Security.Cryptography.X509Certificates.X509Chain chain,
                System.Net.Security.SslPolicyErrors sslPolicyErrors)
            {
                return true;
            };

            SqlConnection connectionDB = new SqlConnection(ConfigurationManager.ConnectionStrings["DashboardDSI"].ToString());
            int indiceServicio = 0;

            SqlCommand cmdIndiceServicio = null;

            if (connectionDB.State == ConnectionState.Closed)
                connectionDB.Open();

            try
            {
                cmdIndiceServicio = new SqlCommand();
                cmdIndiceServicio.Connection = connectionDB;
                cmdIndiceServicio.CommandText = "dashboard_dsi.NOCGetIndiceServicioSolarWinds";
                cmdIndiceServicio.CommandType = CommandType.StoredProcedure;
                indiceServicio = Convert.ToInt32(cmdIndiceServicio.ExecuteScalar());
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                //exEnt.existeError = true;
                //exEnt.tipo = ex.GetType().FullName;
                //exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                //exEnt.error = ex.Message;
                //exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                //exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                //exEnt.detalle = ex.ToString();
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (cmdIndiceServicio != null)
                    cmdIndiceServicio.Dispose();
                if (connectionDB.State == ConnectionState.Open)
                    connectionDB.Close();
            }

            if (indiceServicio > 0)
            {
                SqlCommand cmdBackup = null;
                int BackupDatos = 0;

                if (connectionDB.State == ConnectionState.Closed)
                    connectionDB.Open();

                try
                {
                    cmdBackup = new SqlCommand();
                    cmdBackup.Connection = connectionDB;
                    cmdBackup.CommandText = "dashboard_dsi.NOCBackupDatosSolarWinds";
                    cmdBackup.CommandType = CommandType.StoredProcedure;
                    BackupDatos = Convert.ToInt32(cmdBackup.ExecuteScalar());

                    if (BackupDatos == 0)
                        throw new Exception("Exception: No se pudo realizar el backup de los datos con el procedimiento: NOCBackupDatosSolarWinds");
                }
                catch (Exception ex)
                {
                    StackTrace trace = new StackTrace(ex, true);
                    //exEnt.existeError = true;
                    //exEnt.tipo = ex.GetType().FullName;
                    //exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                    //exEnt.error = ex.Message;
                    //exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                    //exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                    //exEnt.detalle = ex.ToString();
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    if (cmdBackup != null)
                        cmdBackup.Dispose();
                    if (connectionDB.State == ConnectionState.Open)
                        connectionDB.Close();
                }

                if (BackupDatos > 0)
                {
                    string httpRequest = "https://10.121.224.22:17778/SolarWinds/InformationService/v3/Json/Query?query=SELECT oncp.Cliente, onodes.NodeName, onodes.IP_Address, onodes.CPULoad, onodes.PercentMemoryUsed, oncp.Contacto, oncp.Correo, oncp.Tipo, oncp.Brand, oncp.Estado, oncp.Latitude, oncp.Longitude, onodes.StatusDescription FROM Orion.Nodes onodes JOIN Orion.NodesCustomProperties oncp ON onodes.NodeID = oncp.NodeID";
                    HttpWebRequest request = WebRequest.Create(httpRequest) as HttpWebRequest;
                    request.Method = "GET";
                    request.Headers.Add("Authorization", "Basic ZGFzaGJvYXJkOkQ0c2hiMGFyZFQwdEBsc2Vj");
                    request.ContentType = "application/json; charset=utf-8";
                    byte[] bytes = Encoding.UTF8.GetBytes("");
                    request.ContentLength = bytes.Length;
                    request.Proxy = null;
                    HttpWebResponse response = null;

                    try
                    {
                        response = (HttpWebResponse)request.GetResponse();

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            var responseStream = response.GetResponseStream();
                            string respSolarWinds = new StreamReader(responseStream).ReadToEnd();

                            var resultJSON = JObject.Parse(respSolarWinds).SelectToken("results");

                            //var resultJSON = resultJSONG.GroupBy(data => data.SelectToken("NodeName"));

                            SqlCommand command = null;
                            SqlDataReader reader = null;
                            List<DatosClientes> resultDB = null;

                            if (connectionDB.State == ConnectionState.Closed)
                                connectionDB.Open();

                            try
                            {
                                resultDB = new List<DatosClientes>();
                                command = new SqlCommand();
                                command.Connection = connectionDB;
                                command.CommandText = "dashboard_dsi.NOCGetDatosSolarWinds";
                                command.CommandType = CommandType.StoredProcedure;
                                reader = command.ExecuteReader();
                                if (reader.HasRows)
                                {
                                    while (reader.Read())
                                        resultDB.Add(new DatosClientes { Cliente = reader.GetString(0), NodeName = reader.GetString(1), IP_Address = reader.GetString(2), CPULoad = reader.GetDecimal(3), PercentMemoryUsed = reader.GetDecimal(4), Contacto = reader.GetString(5), Correo = reader.GetString(6), Tipo = reader.GetString(7), StatusDescription = reader.GetString(8), Brand = reader.GetString(9), Estado = reader.GetString(10), Latitude = reader.GetString(11), Longitude = reader.GetString(12) });
                                }
                                else
                                    throw new Exception("Exception: reader.HasRows(): el objeto Reader viene vacio en el procedimiento: NOCGetDatosSolarWinds");
                            }
                            catch (Exception ex)
                            {
                                StackTrace trace = new StackTrace(ex, true);
                                //exEnt.existeError = true;
                                //exEnt.tipo = ex.GetType().FullName;
                                //exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                                //exEnt.error = ex.Message;
                                //exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                                //exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                                //exEnt.detalle = ex.ToString();
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                if (reader != null)
                                    reader.Close();
                                if (command != null)
                                    command.Dispose();
                                if (connectionDB.State == ConnectionState.Open)
                                    connectionDB.Close();
                            }

                            var test1 = JsonConvert.DeserializeObject<List<DatosClientes>>(resultJSON.ToString());
                            var test2 = resultDB;

                            var result1 = test1.Where(a => !test2.Select(b => b.NodeName).Contains(a.NodeName));
                            var result2 = test2.Where(a => !test1.Select(b => b.NodeName).Contains(a.NodeName));

                            foreach (var item in result1)
                            {
                                SqlCommand command1 = null;
                                SqlTransaction transfer = null;

                                if (connectionDB.State == ConnectionState.Closed)
                                    connectionDB.Open();

                                try
                                {
                                    transfer = connectionDB.BeginTransaction();
                                    command1 = new SqlCommand();
                                    command1.Connection = connectionDB;
                                    command1.CommandText = "dashboard_dsi.NOCGuardarDatosSolarWinds";
                                    command1.Parameters.AddWithValue("@Cliente", string.IsNullOrEmpty(item.Cliente) ? string.Empty : item.Cliente);
                                    command1.Parameters.AddWithValue("@NodeName", string.IsNullOrEmpty(item.NodeName) ? string.Empty : item.NodeName);
                                    command1.Parameters.AddWithValue("@IP_Address", string.IsNullOrEmpty(item.IP_Address) ? string.Empty : item.IP_Address);
                                    command1.Parameters.AddWithValue("@CPULoad", item.CPULoad);
                                    command1.Parameters.AddWithValue("@PercentMemoryUsed", item.PercentMemoryUsed);
                                    command1.Parameters.AddWithValue("@Contacto", string.IsNullOrEmpty(item.Contacto) ? string.Empty : item.Contacto);
                                    command1.Parameters.AddWithValue("@Correo", string.IsNullOrEmpty(item.Correo) ? string.Empty : item.Correo);
                                    command1.Parameters.AddWithValue("@Tipo", string.IsNullOrEmpty(item.Tipo) ? string.Empty : item.Tipo);
                                    command1.Parameters.AddWithValue("@StatusDescription", string.IsNullOrEmpty(item.StatusDescription) ? string.Empty : item.StatusDescription);
                                    command1.Parameters.AddWithValue("@Brand", string.IsNullOrEmpty(item.Brand) ? string.Empty : item.Brand);
                                    command1.Parameters.AddWithValue("@Estado", string.IsNullOrEmpty(item.Estado) ? string.Empty : item.Estado);
                                    command1.Parameters.AddWithValue("@Latitude", string.IsNullOrEmpty(item.Latitude) ? string.Empty : item.Latitude);
                                    command1.Parameters.AddWithValue("@Longitude", string.IsNullOrEmpty(item.Longitude) ? string.Empty : item.Longitude);

                                    command1.CommandType = CommandType.StoredProcedure;
                                    command1.Transaction = transfer;
                                    int resultInsertDB = Convert.ToInt32(command1.ExecuteScalar());

                                    if (transfer != null)
                                        transfer.Commit();

                                    Console.WriteLine("Llegó: NOCGuardarDatosSolarWinds");

                                    if (resultInsertDB == 0)
                                        throw new Exception("Ha ocurrido un error al ejecutar el procedimiento: NOCGuardarDatosSolarWinds");
                                }
                                catch (Exception ex)
                                {
                                    if (transfer != null)
                                        transfer.Rollback();

                                    StackTrace trace = new StackTrace(ex, true);
                                    //exEnt.existeError = true;
                                    //exEnt.tipo = ex.GetType().FullName;
                                    //exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                                    //exEnt.error = ex.Message;
                                    //exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                                    //exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                                    //exEnt.detalle = ex.ToString();
                                    Console.WriteLine(ex.Message);
                                    break;
                                }
                                finally
                                {
                                    if (transfer != null)
                                        transfer.Dispose();
                                    if (command1 != null)
                                        command1.Dispose();
                                    if (connectionDB.State == ConnectionState.Open)
                                        connectionDB.Close();
                                }
                            }

                            foreach (var item in result2)
                            {
                                SqlCommand command2 = null;
                                SqlTransaction transfer = null;

                                if (connectionDB.State == ConnectionState.Closed)
                                    connectionDB.Open();

                                try
                                {
                                    transfer = connectionDB.BeginTransaction();
                                    command2 = new SqlCommand();
                                    command2.Connection = connectionDB;
                                    command2.CommandText = "dashboard_dsi.NOCEliminarDatosSolarWinds";
                                    command2.Parameters.AddWithValue("@NodeName", item.NodeName);
                                    command2.CommandType = CommandType.StoredProcedure;
                                    command2.Transaction = transfer;
                                    int resultInsertDB = Convert.ToInt32(command2.ExecuteScalar());

                                    if (transfer != null)
                                        transfer.Commit();

                                    Console.WriteLine("Llegó: NOCEliminarDatosSolarWinds");

                                    if (resultInsertDB == 0)
                                        throw new Exception("Ha ocurrido un error al ejecutar el procedimiento: NOCEliminarDatosSolarWinds");
                                }
                                catch (Exception ex)
                                {
                                    if (transfer != null)
                                        transfer.Rollback();

                                    StackTrace trace = new StackTrace(ex, true);
                                    //exEnt.existeError = true;
                                    //exEnt.tipo = ex.GetType().FullName;
                                    //exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                                    //exEnt.error = ex.Message;
                                    //exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                                    //exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                                    //exEnt.detalle = ex.ToString();
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    if (transfer != null)
                                        transfer.Dispose();
                                    if (command2 != null)
                                        command2.Dispose();
                                    if (connectionDB.State == ConnectionState.Open)
                                        connectionDB.Close();
                                }
                            }

                            foreach (var item in resultJSON)
                            {
                                string Cliente = item.SelectToken("Cliente").ToString();
                                string NodeName = item.SelectToken("NodeName").ToString();
                                string IP_Address = item.SelectToken("IP_Address").ToString();
                                int CPULoad = Convert.ToInt32(item.SelectToken("CPULoad"));
                                int PercentMemoryUsed = Convert.ToInt32(item.SelectToken("PercentMemoryUsed"));
                                string Contacto = item.SelectToken("Contacto").ToString();
                                string Correo = item.SelectToken("Correo").ToString();
                                string Tipo = item.SelectToken("Tipo").ToString();
                                string StatusDescription = item.SelectToken("StatusDescription").ToString();
                                string Brand = item.SelectToken("Brand").ToString();
                                string Estado = item.SelectToken("Estado").ToString();
                                string Latitude = item.SelectToken("Latitude").ToString();
                                string Longitude = item.SelectToken("Longitude").ToString();

                                SqlCommand command3 = null;
                                SqlTransaction transfer = null;

                                if (connectionDB.State == ConnectionState.Closed)
                                    connectionDB.Open();

                                try
                                {
                                    transfer = connectionDB.BeginTransaction();
                                    command3 = new SqlCommand();
                                    command3.Connection = connectionDB;
                                    command3.CommandText = "dashboard_dsi.NOCActualizarDatosSolarWinds";
                                    command3.Parameters.AddWithValue("@Cliente", Cliente);
                                    command3.Parameters.AddWithValue("@NodeName", NodeName);
                                    command3.Parameters.AddWithValue("@IP_Address", IP_Address);
                                    command3.Parameters.AddWithValue("@CPULoad", CPULoad);
                                    command3.Parameters.AddWithValue("@PercentMemoryUsed", PercentMemoryUsed);
                                    command3.Parameters.AddWithValue("@Contacto", Contacto);
                                    command3.Parameters.AddWithValue("@Correo", Correo);
                                    command3.Parameters.AddWithValue("@Tipo", Tipo);
                                    command3.Parameters.AddWithValue("@StatusDescription", StatusDescription);
                                    command3.Parameters.AddWithValue("@Brand", Brand);
                                    command3.Parameters.AddWithValue("@Estado", Estado);
                                    command3.Parameters.AddWithValue("@Latitude", Latitude);
                                    command3.Parameters.AddWithValue("@Longitude", Longitude);

                                    command3.CommandType = CommandType.StoredProcedure;
                                    command3.Transaction = transfer;
                                    int resultInsertDB = Convert.ToInt32(command3.ExecuteScalar());

                                    if (transfer != null)
                                        transfer.Commit();

                                    if (resultInsertDB == 0)
                                        throw new Exception("Ha ocurrido un error al ejecutar el procedimiento: NOCActualizarDatosSolarWinds");
                                }
                                catch (Exception ex)
                                {
                                    if (transfer != null)
                                        transfer.Rollback();

                                    StackTrace trace = new StackTrace(ex, true);
                                    //exEnt.existeError = true;
                                    //exEnt.tipo = ex.GetType().FullName;
                                    //exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                                    //exEnt.error = ex.Message;
                                    //exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                                    //exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                                    //exEnt.detalle = ex.ToString();
                                    Console.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    if (transfer != null)
                                        transfer.Dispose();
                                    if (command3 != null)
                                        command3.Dispose();
                                    if (connectionDB.State == ConnectionState.Open)
                                        connectionDB.Close();
                                }
                            }
                        }
                        else
                            throw new Exception("{'error': 'StatusCode no OK'}");
                        response.Close();
                    }
                    catch (Exception ex)
                    {
                        if (response != null)
                            response.Close();

                        StackTrace trace = new StackTrace(ex, true);
                        //solarWinds.error.existeError = true;
                        //solarWinds.error.tipoError = ex.GetType().FullName;
                        //solarWinds.error.archivoOrigen = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                        //solarWinds.error.error = ex.Message;
                        //solarWinds.error.linea = trace.GetFrame(0).GetFileLineNumber();
                        //solarWinds.error.columna = trace.GetFrame(0).GetFileColumnNumber();
                        //solarWinds.error.detalleError = ex.ToString();
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            else
                Console.WriteLine("El servicio está apagado");

            Console.ReadLine();
        }
    }
}
