'use strict'

var $ = jQuery.noConflict()
var $ = $.noConflict()

var queueModales = new Array()
var offsetY = null
var workModalProcesando = false

var modalesHTML = {

    modalCargando: function () {
        return '\
            <div class="modal-cargando">\
	            <img src="'+ $.path + 'Public/img/cargando-modal.gif" ondragstart="return false">\
	            <span>Cargando</span>\
            </div>\
        '
    },

    modalProcesando: function () {
        return '\
            <table class="modal-procesando"><tr><td>\
	            <div class="contenido-modal-procesando" id="contenido-modal-procesando">\
		            <img src="'+ $.path + 'Public/img/cargando-modal.gif" ondragstart="return false">\
		            <span>Procesando</span>\
	            </div>\
            </td></tr></table>\
        '
    },

    modalGral: function () {
        return '\
            <table class="modal-gral" onclick="autoCerrarModal(event, this)"><tr><td>\
	            <div class="contenido-modal-gral" id="contenido-modal-gral">\
		            <div class="cabecera-modal-gral">\
			            <span class="titulo-modal-gral">Cargando</span>\
			            <button class="cerrar-modal-contenido" onclick="cerrarModalGral()">X</button>\
		            </div>\
		            <div class="cuerpo-modal-gral">\
                        <div style="text-align: center">\
                            <img src="'+ $.path + 'Public/img/cargando-modal.gif" ondragstart="return false" style="width: 50px; height: auto">\
                        </div>\
                    </div>\
	            </div>\
            </td></tr></table>\
        '
    },

    modalContenido: function () {
        return '\
            <table class="modal-contenido" onclick="autoCerrarModal(event, this)"><tr><td>\
	            <div class="contenido-modal-contenido" id="contenido-modal-contenido">\
                    <div class="cabecera-modal-contenido">\
			            <span class="titulo-modal-contenido">Cargando</span>\
			            <button class="cerrar-modal-contenido" onclick="cerrarModalContenido()">X</button>\
		            </div>\
		            <div class="cuerpo-modal-contenido">\
                        <div class="img-cargando">\
			            <img src="'+ $.path + 'Public/img/cargando-modal.gif">\
		            </div>\
                    </div>\
	            </div>\
            </td></tr></table>\
        '
    }

}

function abrirModalCargando() {
    document.body.innerHTML += modalesHTML.modalCargando()
    $('.modal-cargando').fadeIn(100)
}

function cerrarModalCargando() {
    $('.modal-cargando').fadeOut(100)
    $('.modal-cargando').remove()
}

function abrirModalProcesando() {
    $('.contentAllHTML').css({ 'top': -offsetY })
    $('.contentAllHTML').addClass('bodyModal')
    document.body.insertAdjacentHTML('beforeend', modalesHTML.modalProcesando())
    $('.modal-procesando').fadeIn(100)
    workModalProcesando = true
}

function cerrarModalProcesando() {
    $('.modal-procesando').fadeOut(100)
    $('.modal-procesando').remove()

    if (queueModales.length == 0) {
        $('.contentAllHTML').removeClass('bodyModal')
        $('.contentAllHTML').css({ 'top': 0 })
    }
    workModalProcesando = false
}

function abrirModalGral() {
    offsetY = window.pageYOffset
    $('body').css({ 'overflow-y': 'scroll' })
    $('.contentAllHTML').css({ 'top': -offsetY })
    $('.contentAllHTML').addClass('bodyModal')
    document.body.insertAdjacentHTML('beforeend', modalesHTML.modalGral())
    $('.modal-gral').fadeIn(100)
    queueModales.push('modal-gral')
}

function cerrarModalGral() {
    if ($.xhrPool['uno'] != null) {
        $.xhrPool['uno'].abort()
        $.xhrPool['uno'] = null
    }
    $('.modal-gral').fadeOut(100)
    $('.modal-gral').remove()

    $('.contentAllHTML').removeClass('bodyModal')
    $('.contentAllHTML').css({ 'top': 0 })
    $(document).scrollTop(offsetY)
    $('body').css({ 'overflow-y': 'scroll' })
    queueModales.splice(queueModales.indexOf('modal-gral'), 1)
}

function autoCerrarModal(event, self) {
    if (document.getElementById($(self).find('div').attr('id')) != null) {
        var parent = document.getElementById($(self).find('div').attr('id')).parentElement
        if (event.target == parent && parent.contains(event.target)) {
            if ($.xhrPool['uno'] != null) {
                $.xhrPool['uno'].abort()
                $.xhrPool['uno'] = null
            }
            var clase = $(self).attr("class")
            $('.' + clase).fadeOut(100)
            $('.' + clase).remove()

            $('.contentAllHTML').removeClass('bodyModal')
            $('.contentAllHTML').css({ 'top': 0 })
            $(document).scrollTop(offsetY)
            $('body').css({ 'overflow-y': 'scroll' })
            queueModales.splice(queueModales.indexOf(clase), 1)
        }
    }
}

document.onkeydown = function (event) {
    if (event.keyCode == 27) {
        if (queueModales != null && queueModales.length > 0 && workModalProcesando == false) {
            if ($.xhrPool['uno'] != null) {
                $.xhrPool['uno'].abort()
                $.xhrPool['uno'] = null
            }
            var clase = queueModales.pop()
            $('.' + clase).fadeOut(100)
            $('.' + clase).remove()

            $('.contentAllHTML').removeClass('bodyModal')
            $('.contentAllHTML').css({ 'top': 0 })
            $(document).scrollTop(offsetY)
            $('body').css({ 'overflow-y': 'scroll' })
        }
    }
}