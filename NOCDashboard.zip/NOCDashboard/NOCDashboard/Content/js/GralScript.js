'use strict'

var $ = jQuery.noConflict()
var $ = $.noConflict()

var modalesJS = document.createElement('script')
modalesJS.type = 'text/javascript'
modalesJS.src = $.path + 'Public/js/Modales.js'
document.head.appendChild(modalesJS)

var ncrtp = document.createElement('script')
ncrtp.type = 'text/javascript'
ncrtp.src = $.path + 'Public/js/ncrtp.js'
document.head.appendChild(ncrtp)

var ncrtpHelpers = document.createElement('script')
ncrtpHelpers.type = 'text/javascript'
ncrtpHelpers.src = $.path + 'Public/js/ncrtpHelpers.js'
document.head.appendChild(ncrtpHelpers)

var ncrtpes = document.createElement('script')
ncrtpes.type = 'text/javascript'
ncrtpes.src = $.path + 'Public/js/ncrtpes.js'
document.head.appendChild(ncrtpes)

var modalesCSS = document.createElement('link')
modalesCSS.rel = 'stylesheet'
modalesCSS.type = 'text/css'
modalesCSS.href = $.path + 'Public/css/Modales.css'
modalesCSS.media = 'all'
document.head.appendChild(modalesCSS)

function limpiarAlert() {
    $('.alert-dismissible').hide()
    $('.alert-dismissible .alert-txt').html('')
    $('.alert-dismissible').removeClass('alert-success')
    $('.alert-dismissible').removeClass('alert-info')
    $('.alert-dismissible').removeClass('alert-warning')
    $('.alert-dismissible').removeClass('alert-danger')
}

function cerrarSesion() {
    try {
        limpiarAlert()
        abrirModalProcesando()

        $.ajax({
            url: $.path + 'Login/CerrarSesion',
            data: '',
            type: 'POST',
            dataType: 'JSON',
            contentType: false,
            processData: false,
            beforeSend: function () { },
            success: function (response) {
                window.location.href = $.path + 'Login'
            },
            error: function (response) {
                cerrarModalProcesando()
            }
        })
    } catch (err) {
        cerrarModalProcesando()
    }
}

//var timerActualizarSesion = setTimeout(function () { actualizarSesion() }, 60000)

//function actualizarSesion()
//{
//    clearTimeout(timerActualizarSesion)

//    $.ajax({
//        url: '/StarkPBX/Inicio/ActualizarSesion',
//        data: '',
//        type: 'POST',
//        contentType: 'application/json;charset=utf-8',
//        dataType: 'JSON',
//        beforeSend: function () { },
//        success: function (response) {
//            var tiempoSesion = DecryptData(response[0])
//            console.log(tiempoSesion)
//            if (tiempoSesion >= 10) {
//                window.location.href = DecryptData(response[1])
//            }
//            timerActualizarSesion = setTimeout(function () { actualizarSesion() }, 60000)
//        },
//        error: function (response) {
//            timerActualizarSesion = setTimeout(function () { actualizarSesion() }, 60000)
//        }
//    })
//}

var dicInputsValidaciones = {
    numError: function (error) {
        switch (error) {
            case 1:
                return 'Campo requerido'
                break;
            case 2:
                return 'Se espera un valor numerico'
                break;
            case 3:
                return 'Se espera un valor decimal'
                break;
            case 4:
                return 'Número de caracteres excedido'
                break;
            case 5:
                return 'Formato de fecha incorrecto'
                break;
            case 6:
                return 'Se espera un email en este campo'
                break;
            case 7:
                return 'Ingresar 10 digitos numericos'
                break;
            case 8:
                return 'Ingresar 5 digitos numericos'
                break;
        }
    }
}

function inversaCaracteresEspeciales(texto) {
    texto = texto.replace(/&amp;/g, '&')
            .replace(/&#35;/g, '#')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&#33;/g, '!')
            .replace(/&#36;/g, '$')
            .replace(/&#37;/g, '%')
            .replace(/&#39;/g, '\'')
            .replace(/&#40;/g, '(')
            .replace(/&#41;/g, ')')
            .replace(/&#42;/g, '*')
            .replace(/&#43;/g, '+')
            .replace(/&#44;/g, ',')
            .replace(/&#45;/g, '-')
            .replace(/&#46;/g, '.')
            .replace(/&#47;/g, '/')
            .replace(/&#58;/g, ':')
            .replace(/&#61;/g, '=')
            .replace(/&#63;/g, '?')
            .replace(/&#91;/g, '[')
            .replace(/&#93;/g, ']')
            .replace(/&#94;/g, '^')
            .replace(/&#95;/g, '_')
            .replace(/&#123;/g, '{')
            .replace(/&#124;/g, '|')
            .replace(/&#125;/g, '}')
            .replace(/&#126;/g, '~')
            .replace(/&iquest;/g, '¿')
            .replace(/&iexcl;/g, '¡')
            .replace(/(<([^>]+)>)/ig, "")

    return texto;
}

function quitaCaracteresEspeciales(texto) {
    texto = texto.replace(/(<([^>]+)>)/ig, "")
            .replace(/(&lt;([^>]+)&gt;)/ig, "")
            .replace(/(&#60;([^>]+)&#62;)/ig, "")
            .replace(/&/g, '&amp;')
            .replace(/#/g, '&#35;')
            .replace(/\\/g, '')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\"/g, '&quot;')
            .replace(/!/g, '&#33;')
            .replace(/\$/g, '&#36;')
            .replace(/%/g, '&#37;')
            .replace(/'/g, '&#39;')
            .replace(/\(/g, '&#40;')
            .replace(/\)/g, '&#41;')
            .replace(/\*/g, '&#42;')
            .replace(/\+/g, '&#43;')
            .replace(/,/g, '&#44;')
            .replace(/-/g, '&#45;')
            .replace(/\./g, '&#46;')
            .replace(/\//g, '&#47;')
            .replace(/:/g, '&#58;')
            .replace(/=/g, '&#61;')
            .replace(/\?/g, '&#63;')
            .replace(/\[/g, '&#91;')
            .replace(/\[/g, '&#93;')
            .replace(/\^/g, '&#94;')
            .replace(/_/g, '&#95;')
            .replace(/{/g, '&#123;')
            .replace(/\|/g, '&#124;')
            .replace(/}/g, '&#125;')
            .replace(/~/g, '&#126;')
            .replace(/¿/g, '&iquest;')
            .replace(/¡/g, '&iexcl;')

    return texto;
}

function validarEntrada(self) {
    try {
        var texto = self.value
        texto = texto.replace(/(<([^>]+)>)/ig, "")
                .replace(/(&lt;([^>]+)&gt;)/ig, "")
                .replace(/(&#60;([^>]+)&#62;)/ig, "")
        self.value = texto
        $(self).tooltip('option', 'content', '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + $(self).prop('placeholder'))
    } catch (err) {
    }
}

function limpiaContrasena(texto) {
    texto = texto.replace(/(<([^>]+)>)/ig, "")
            .replace(/(&lt;([^>]+)&gt;)/ig, "")
            .replace(/(&#60;([^>]+)&#62;)/ig, "")
    return texto
}

function validarNumero(texto) {
    return new RegExp('^[0-9]+$').test(texto)
}

function validarDecimal(texto) {
    return new RegExp('^[0-9|,|.]+$').test(texto)
}

function validarCorreo(texto) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(texto).toLowerCase());
}

function validarCamposInput() {
    var objResp = new Object()
    objResp.resp = true
    objResp.json = '';
    if (arguments[0].length > 0) {
        for (var i = 0; i < arguments[0].length; i++) {
            if (arguments[0][i].tipo !== 'file') {
                var texto = arguments[0][i].valor.trim()
                var vacio = (texto === '' || texto === null || texto.length == 0) ? true : false
                if (arguments[0][i].requerido && vacio) {
                    objResp.id = arguments[0][i].id
                    objResp.error = 1
                    objResp.resp = false
                    break
                }

                if (arguments[0][i].tipo === 'recaptcha') {
                    $.CarRG = texto
                }

                if (arguments[0][i].tipo === 'texto') {
                    if (texto.length > 200) {
                        objResp.id = arguments[0][i].id
                        objResp.error = 4
                        objResp.resp = false
                        break
                    }
                }

                if (arguments[0][i].tipo === 'telefono') {
                    if (texto.length > 10 || texto.length < 10 || validarNumero(texto) == false) {
                        objResp.id = arguments[0][i].id
                        objResp.error = 7
                        objResp.resp = false
                        break
                    }
                }
                
                if (arguments[0][i].tipo === 'codigoPostal') {
                    if (texto.length > 5 || texto.length < 5 || validarNumero(texto) == false) {
                        objResp.id = arguments[0][i].id
                        objResp.error = 8
                        objResp.resp = false
                        break
                    }
                }

                if (arguments[0][i].tipo === 'correo') {
                    if (texto.length > 200) {
                        objResp.id = arguments[0][i].id
                        objResp.error = 4
                        objResp.resp = false
                        break
                    } else if (!validarCorreo(texto)) {
                        objResp.id = arguments[0][i].id
                        objResp.error = 6
                        objResp.resp = false
                        break
                    }
                }

                if (arguments[0][i].tipo === 'textolargo') {
                    if (texto.length > 500) {
                        objResp.id = arguments[0][i].id
                        objResp.error = 4
                        objResp.resp = false
                        break
                    }
                }

                if (arguments[0][i].tipo === 'numero') {
                    if (texto != '' && texto != null && texto.length > 0) {
                        if (texto.length > 10) {
                            objResp.id = arguments[0][i].id
                            objResp.error = 4
                            objResp.resp = false
                            break
                        } else if (!validarNumero(texto)) {
                            objResp.id = arguments[0][i].id
                            objResp.error = 2
                            objResp.resp = false
                            break
                        }
                    }
                }

                if (arguments[0][i].tipo === 'decimal') {
                    if (texto != '' && texto != null && texto.length > 0) {
                        if (texto.length > 30) {
                            objResp.id = arguments[0][i].id
                            objResp.error = 4
                            objResp.resp = false
                            break
                        } else if (!validarDecimal(texto)) {
                            objResp.id = arguments[0][i].id
                            objResp.error = 3
                            objResp.resp = false
                            break
                        }
                    }
                }

                if (arguments[0][i].tipo === 'fecha') {

                }
            }
        }
        if (objResp.resp) {
            if (arguments[1] === 'submit') {
                for (var i = 0; i < arguments[0].length; i++) {
                    var texto = arguments[0][i].valor
                    var id = arguments[0][i].id

                    if ((arguments[0][i].tipo === 'texto' || arguments[0][i].tipo === 'textolargo') && texto !== '' && texto !== null && texto.length > 0) {
                        texto = inversaCaracteresEspeciales(texto.trim())
                        texto = quitaCaracteresEspeciales(texto.trim())
                    }

                    if (arguments[0][i].tipo === 'texto' || arguments[0][i].tipo === 'correo' || arguments[0][i].tipo === 'textolargo' || arguments[0][i].tipo === 'numero' || arguments[0][i].tipo === 'decimal' || arguments[0][i].tipo === 'fecha' || arguments[0][i].tipo === 'telefono' || arguments[0][i].tipo === 'codigoPostal') {
                        $('#' + id).val(encrypt(texto.trim(), $.CarRG))
                    }
                }
            } else if (arguments[1] === 'ajax') {
                var formData = new FormData()

                for (var i = 0; i < arguments[0].length; i++) {
                    var texto = arguments[0][i].valor
                    var id = arguments[0][i].id

                    if ((arguments[0][i].tipo === 'texto' || arguments[0][i].tipo === 'textolargo') && texto !== '' && texto !== null && texto.length > 0) {
                        texto = inversaCaracteresEspeciales(texto.trim())
                        texto = quitaCaracteresEspeciales(texto.trim())
                    }

                    if (arguments[0][i].tipo === 'texto' || arguments[0][i].tipo === 'correo' || arguments[0][i].tipo === 'textolargo' || arguments[0][i].tipo === 'numero' || arguments[0][i].tipo === 'decimal' || arguments[0][i].tipo === 'fecha' || arguments[0][i].tipo === 'telefono')
                        formData.append(id, encrypt(texto.trim(), $.CarRG))
                    else
                        formData.append(id, texto)
                }
                objResp.json = formData
            }
        }
    } else {
        objResp.resp = false
        objResp.error = 0
    }
    return objResp
}

function validarArrayIds(array) {
    var objResp = new Object()
    objResp.resp = true
    objResp.error = 0
    objResp.json = '';

    if (array.length == 0 || array === null || array === undefined) {
        objResp.resp = false
        objResp.error = 1
    } else {
        var formData = new FormData()
        for (var i = 0; i < array.length; i++) {
            var id = array[i]
            if (id != '' && id != null && id.length > 0) {
                id = encrypt(id, $.CarRG)
                formData.append('pos' + i, id)
            } else {
                objResp.resp = false
                objResp.error = 2
                break
            }
        }
    }
    objResp.json = formData
    return objResp
}

function tableTR(event) {
    window.location = $(event).data("href")
}