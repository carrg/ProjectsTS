﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NOCDashboard.Controllers
{
    public class ErrorController : Controller
    {
        public ActionResult KeyMasterTimeExpired()
        {
            return View();
        }

        public ActionResult KeyMasterCommunicationFailed()
        {
            return View();
        }

        public ActionResult UnknownError()
        {
            return View();
        }

        public ActionResult SessionError()
        {
            Session.RemoveAll();
            Session.Clear();
            Session.Abandon();

            return View();
        }
    }
}
