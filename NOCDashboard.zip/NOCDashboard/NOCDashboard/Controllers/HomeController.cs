﻿using NOCDashboard.Libs;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Windows.Forms;

namespace NOCDashboard.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, NoStore = true, VaryByParam = "none")]
    public class HomeController : Controller
    {
        MisFunciones misFunciones = null;

        public HomeController()
        {
            this.misFunciones = new MisFunciones();
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult Index()
        {
            if (Session != null && Session["NOCDASH_estadoSesion"] != null)
            {
                if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 1)
                    Response.Write("Bienvenido");
                else if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 2)
                    return RedirectToAction("NewSession", "Account");
                else
                    return RedirectToAction("", "Account");
            }
            else
                return RedirectToAction("", "Account");
            return View();
        }

    }
}
