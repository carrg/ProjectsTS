﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NOCDashboard.Libs;
using NOCDashboard.Models;
using NOCDashboard.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Windows.Forms;

namespace NOCDashboard.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, NoStore = true, VaryByParam = "none")]
    public class AccountController : Controller
    {
        private MisFunciones misFunciones = null;
        private AccountModel accountModel = null;
        private ExceptionEntitie exEnt = null;

        public AccountController() 
        {
            this.misFunciones = new MisFunciones();
            
            // this.dispositivo = new Dispositivo();
            // this.dispositivo = JsonConvert.DeserializeObject<Dispositivo>(misFunciones.getDispositivo());

            this.accountModel = new AccountModel(this.misFunciones.getDispositivo());
            this.exEnt = new ExceptionEntitie();   
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult Index()
        {
            bool existeSesion = false;
            if (Session != null && Session["NOCDASH_estadoSesion"] != null)
            {
                if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) != 0)
                    existeSesion = true;
            }
            ViewBag.existeSesion = existeSesion;

            var test = this.misFunciones.getDispositivo();

            Response.Write("IP: " + test.getIP());
            Response.Write("<br />");
            Response.Write("Navegador: " + test.getNavegador());
            Response.Write("<br />");
            Response.Write("Plataforma: " + test.getPlataforma());
            Response.Write("<br />");
            Response.Write("PC Name: " + test.getPCName());
            Response.Write("<br />");
            Response.Write("Dominio Red: " + test.getDominioRed());
            Response.Write("<br />");
            Response.Write("Usuario Red: " + test.getUsuarioRed());
            Response.Write("<br />");
            Response.Write("Maquina Red: " + test.getMaquinaRed());

            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult Login()
        {
            bool existeSesion = false;
            try
            {
                var test = Request.QueryString;

                if (Request.QueryString.Count <= 0)
                {
                    HttpWebRequest request = null;
                    HttpWebResponse response = null;
                    Stream responseStream = null;

                    try
                    {
                        request = (HttpWebRequest)WebRequest.Create("https://portal.socio.gs/Login5/Token/token.aspx?parametro1=CarRG&parametro2=CarRG&id=200") as HttpWebRequest;
                        byte[] bytes = Encoding.UTF8.GetBytes("");
                        request.ContentType = "application/json; charset=utf-8";
                        request.ContentLength = bytes.Length;
                        request.Method = "POST";
                        request.Proxy = null;

                        response = (HttpWebResponse)request.GetResponse();

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            responseStream = response.GetResponseStream();
                            var responseVal = new StreamReader(responseStream).ReadToEnd();

                            if (!string.IsNullOrEmpty(responseVal))
                            {
                                JavaScriptSerializer json = new JavaScriptSerializer();
                                var responseArray = json.Deserialize<String[]>(responseVal);
                                if (responseArray[0].Equals("OK"))
                                {
                                    string strURL = this.misFunciones.EncriptaGS("http://localhost:33530/NOCDashboard/Account/Login");
                                    strURL = Server.UrlEncode(strURL);
                                    Response.Redirect(ConfigurationManager.AppSettings["urlLogin"] + "token=" + responseArray[1] + "&id=" + ConfigurationManager.AppSettings["idAplicacion"] + "&nurl=" + strURL);
                                }
                                else
                                    return RedirectToAction("KeyMasterCommunicationFailed", "Error");
                                //Response.Write("Error de comunicación");
                            }
                            else
                                return RedirectToAction("KeyMasterCommunicationFailed", "Error");
                            //Response.Write("Error de comunicación");
                        }
                        else
                            return RedirectToAction("KeyMasterCommunicationFailed", "Error");
                        //Response.Write("Error de comunicación");
                    }
                    catch (Exception ex)
                    {
                        StackTrace trace = new StackTrace(ex, true);
                        exEnt.existeError = true;
                        exEnt.tipo = ex.GetType().FullName;
                        exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                        exEnt.error = ex.Message;
                        exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                        exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                        exEnt.detalle = ex.ToString();
                        this.accountModel.registrarErrorAnonimo(this.exEnt);
                        return RedirectToAction("UnknownError", "Error");
                    }
                    finally
                    {
                        if (response != null)
                        {
                            response.Dispose();
                            response.Close();
                        }
                        if (responseStream != null)
                        {
                            responseStream.Dispose();
                            responseStream.Close();
                        }
                    }
                }
                else
                {
                    if (Session != null && Session["NOCDASH_estadoSesion"] != null)
                    {
                        if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 1)
                            return RedirectToAction("", "Home");
                        else if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 2)
                            return RedirectToAction("NewSession", "Account");
                    }
                    
                    string xllave = ConfigurationManager.AppSettings["key"].ToString();
                    string xencripta = Request.QueryString.ToString();
                    string[] xvariablessesion = xencripta.Split('&');
                    string estatus = string.Empty;
                    DateTime xfec = DateTime.Now.AddSeconds(60);    //        ToString("ddMMyyyy hh:mm:ss"));
                    //string xfecha = DateTime.Now.ToString("ddMMyyyy hh:mm:ss");

                    // ciclo de 60 segundos +- para encontrar la coincidencia con la llave dinamica
                    for (int i = 1; i <= 120; i++)
                    {
                        try
                        {
                            xencripta = this.misFunciones.EncriptaGS(xfec.AddSeconds(-i).ToString("ddMMyyyy hh:mm:ss"));
                            xllave = xllave.Substring(0, 16) + xencripta.Substring(xencripta.Length - 16, 16);
                            xencripta = this.misFunciones.DesencriptaGS(Server.UrlDecode(xvariablessesion[1].Substring(xvariablessesion[1].IndexOf("=") + 1, (xvariablessesion[1].Length - xvariablessesion[1].IndexOf("=") - 1))), xllave);
                            if (!String.IsNullOrEmpty(xencripta) && !xencripta.Contains("?"))
                            {
                                estatus = "OK";
                                break;
                            }
                        }
                        catch
                        {
                            estatus = "ERROR";
                        }
                    }

                    if (estatus.Equals("OK"))
                    {
                        String noEmpleado = this.misFunciones.DesencriptaGS(Server.UrlDecode(xvariablessesion[1].Substring(xvariablessesion[1].IndexOf("=") + 1, (xvariablessesion[1].Length - xvariablessesion[1].IndexOf("=") - 1))), xllave);

                        var respuestaDB = this.accountModel.validarAccesos(noEmpleado, ref this.exEnt);
                        var respArrDB = respuestaDB.ToArray();

                        if (this.exEnt.existeError)
                        {
                            this.accountModel.registrarErrorAnonimo(this.exEnt);
                            return RedirectToAction("UnknownError", "Error");
                        }
                        else
                        {
                            Session["NOCDASH_estadoSesion"] = 0;
                            Session["NOCDASH_shortName"] = this.misFunciones.DesencriptaGS(Server.UrlDecode(xvariablessesion[0].Substring(xvariablessesion[0].IndexOf("=") + 1, (xvariablessesion[0].Length - xvariablessesion[0].IndexOf("=") - 1))), xllave);
                            Session["NOCDASH_NoEmpleado"] = noEmpleado;
                            Session["NOCDASH_Nombre"] = this.misFunciones.DesencriptaGS(Server.UrlDecode(xvariablessesion[2].Substring(xvariablessesion[2].IndexOf("=") + 1, (xvariablessesion[2].Length - xvariablessesion[2].IndexOf("=") - 1))), xllave);
                            Session["NOCDASH_Empresa"] = this.misFunciones.DesencriptaGS(Server.UrlDecode(xvariablessesion[3].Substring(xvariablessesion[3].IndexOf("=") + 1, (xvariablessesion[3].Length - xvariablessesion[3].IndexOf("=") - 1))), xllave);

                            Session["NOCDASH_ip"] = misFunciones.getDispositivo().getIP();
                            Session["NOCDASH_navegador"] = misFunciones.getDispositivo().getNavegador();
                            Session["NOCDASH_plataforma"] = misFunciones.getDispositivo().getPlataforma();
                            Session["NOCDASH_pcName"] = misFunciones.getDispositivo().getPCName();
                            Session["NOCDASH_dominioRed"] = misFunciones.getDispositivo().getDominioRed();

                            Session["NOCDASH_idAcceso"] = respArrDB[1];
                            Session["NOCDASH_nuevoDispositivo"] = respArrDB[2];
                            Session["NOCDASH_idUsuario"] = respArrDB[3];
                            Session["NOCDASH_idDispositivo"] = respArrDB[4];
                            
                            if (respuestaDB.First() == 0)
                                return RedirectToAction("UnknownError", "Error");
                            if (respuestaDB.First() == 1)
                            {
                                Session["NOCDASH_estadoSesion"] = 1;
                                return RedirectToAction("", "Home");
                            }
                            else if (respuestaDB.First() == 2)
                                return RedirectToAction("UnknownUser", "Account");
                            else if (respuestaDB.First() == 3)
                            {
                                Session["NOCDASH_estadoSesion"] = 2;
                                return RedirectToAction("NewSession", "Account");
                            }
                            else
                                throw new Exception("Ha ocurrido un error desconocido");
                        }

                        // Url Logout : https://portal.socio.gs/logout_azteca/cerrar_sesion.html
                    }
                    else
                        return RedirectToAction("KeyMasterTimeExpired", "Error");
                    //Response.Write("Error en sesión tiempo expirado.....");
                    //return RedirectToAction("", "Account");
                }

                if (Session != null && Session["NOCDASH_estadoSesion"] != null)
                {
                    if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) != 0)
                        existeSesion = true;
                }
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
                this.accountModel.registrarErrorAnonimo(this.exEnt);
                return RedirectToAction("UnknownError", "Error");
            }
            ViewBag.existeSesion = existeSesion;

            return View("~/Views/Account/Index.cshtml");
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult UnknownUser()
        {
            try
            {
                Session.RemoveAll();
                Session.Clear();
                Session.Abandon();
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
                this.accountModel.registrarErrorAnonimo(this.exEnt);
                return RedirectToAction("UnknownError", "Error");
            }

            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult NewSession()
        {
            string statusError = string.Empty;
            try 
            {
                if (Session != null && Session["NOCDASH_estadoSesion"] != null)
                {
                    if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 1)
                        return RedirectToAction("", "Home");
                    else if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 2)
                    {
                        if (!misFunciones.validarDispositivo(misFunciones.getDispositivo(), Session))
                        {
                            statusError = "errorCookie";
                            throw new Exception("Los parametros del dispositivo no coinciden");
                        }
                    }
                    else
                        return RedirectToAction("", "Account");
                }
                else
                    return RedirectToAction("", "Account");
            }
            catch(Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
                this.accountModel.registrarErrorAnonimo(this.exEnt);
                if (statusError.Equals("errorCookie"))
                    return RedirectToAction("SessionError", "Error");
                else
                    return RedirectToAction("UnknownError", "Error");
            }

            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public JsonResult AcceptNewSession(/*string indexTest1, string contentType, Encoding contentEncoding, JsonRequestBehavior behavior */)
        {
            string url = string.Empty;
            string resp = "ok";

            try
            {
                if (Session != null && Session["NOCDASH_estadoSesion"] != null)
                {
                    if (Convert.ToInt32(Session["NOCDASH_estadoSesion"]) == 2)
                    {
                        if (misFunciones.validarDispositivo(misFunciones.getDispositivo(), Session))
                        {
                            int idUsuario = Session["NOCDASH_idUsuario"] != null ? Convert.ToInt32(Session["NOCDASH_idUsuario"]) : 0;
                            int idDispositivo = Session["NOCDASH_idDispositivo"] != null ? Convert.ToInt32(Session["NOCDASH_idDispositivo"]) : 0;

                            if (idUsuario != 0 && idDispositivo != 0)
                            {
                                var respuestaDB = this.accountModel.nuevaSesion(idUsuario, idDispositivo, ref this.exEnt);
                                var respArrDB = respuestaDB.ToArray();

                                if (this.exEnt.existeError)
                                {
                                    this.accountModel.registrarErrorAnonimo(this.exEnt);
                                    resp = "errorDesconocido";
                                }
                                else if(respuestaDB.First() == 1)
                                {
                                    Session["NOCDASH_idAcceso"] = respArrDB[1];
                                    url = Url.Action("", "Home");   
                                }
                            }
                            else
                            {
                                resp = "errorSesion";
                                throw new Exception("No existe sesión: idUsuario, idDispositivo");
                            }
                        }
                        else
                        {
                            resp = "errorCookie";
                            throw new Exception("Los parametros del dispositivo no coinciden");
                        }
                    }
                    else
                    {
                        resp = "errorSesion";
                        throw new Exception("No existe sesión");
                    }
                }
                else
                {
                    resp = "errorSesion";
                    throw new Exception("No existe sesión");
                }
            }
            catch(Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
                this.accountModel.registrarErrorAnonimo(this.exEnt);
                resp = "errorDesconocido";
            }

            return Json(new { resp = resp, url = url }, JsonRequestBehavior.AllowGet);
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult CancelNewSession()
        {
            string statusError = string.Empty;
            try
            {
                if (Session != null && Session["NOCDASH_estadoSesion"] != null && Session["NOCDASH_idUsuario"] != null)
                {
                    if (misFunciones.validarDispositivo(misFunciones.getDispositivo(), Session))
                    {
                        Session.RemoveAll();
                        Session.Clear();
                        Session.Abandon();
                    }
                    else
                    {
                        statusError = "errorCookie";
                        throw new Exception("Los parametros del dispositivo no coinciden");
                    }
                }
            }
            catch(Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
                this.accountModel.registrarErrorAnonimo(this.exEnt);
                if (statusError.Equals("errorCookie"))
                    return RedirectToAction("SessionError", "Error");
                else
                    return RedirectToAction("UnknownError", "Error");
            }
            return View();
        }
    }
}
