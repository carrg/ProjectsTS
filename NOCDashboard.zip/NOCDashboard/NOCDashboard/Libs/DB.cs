﻿using NOCDashboard.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Windows.Forms;

namespace NOCDashboard.Libs
{
    public class DB
    {

        public SqlConnection connectionDB;
        private Dispositivo dispositivo = null;

        public DB(Dispositivo dispositivo)
        {
            this.connectionDB = new SqlConnection(ConfigurationManager.ConnectionStrings["TS_DashboardNOC_String"].ToString());            
            this.dispositivo = dispositivo;
        }

        public void registrarErrorAnonimo(ExceptionEntitie ex)
        { 
            SqlCommand command  = null;

            try
            {
                if (this.connectionDB.State == ConnectionState.Closed)
                    this.connectionDB.Open();

                command = new SqlCommand();
                command.Connection = this.connectionDB;
                command.CommandText = "NOCDash.RegistrarErrorAnonimo";
                command.Parameters.AddWithValue("@tipo", ex.tipo);
                command.Parameters.AddWithValue("@archivo", ex.archivo);
                command.Parameters.AddWithValue("@linea", ex.linea);
                command.Parameters.AddWithValue("@columna", ex.linea);
                command.Parameters.AddWithValue("@error", ex.error);
                command.Parameters.AddWithValue("@detalle", ex.detalle);
                command.Parameters.AddWithValue("@ip", this.dispositivo.getIP());
                command.Parameters.AddWithValue("@navegador", this.dispositivo.getNavegador());
                command.Parameters.AddWithValue("@plataforma", this.dispositivo.getPlataforma());
                command.Parameters.AddWithValue("@pcName", this.dispositivo.getPCName());
                command.Parameters.AddWithValue("@dominioRed", this.dispositivo.getDominioRed());
                command.CommandType = CommandType.StoredProcedure;
                command.ExecuteNonQuery();
            }
             catch (Exception e) 
             { }
             finally
             {
                 if (command != null)
                     command.Dispose();
                 if (this.connectionDB.State == ConnectionState.Open)
                     this.connectionDB.Close();
             }
        }
    }
}