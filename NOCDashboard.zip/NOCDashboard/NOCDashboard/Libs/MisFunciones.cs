﻿using Newtonsoft.Json;
using NOCDashboard.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Windows.Forms;

namespace NOCDashboard.Libs
{
    public class MisFunciones
    {
        protected string _NumbersOnly = @"^[\d]{0,100}$";
        protected string _NumbersDecimal = @"^[\d|,|.]{0,100}$";
        protected string _DateOnly = @"^[\d]{1,2}/[\d]{1,2}/\d\d\d\d$";
        protected string _NumberTextOutSpaces = @"^[a-zA-Z0-9]{1,50}$";
        protected string _ReqQryStr = @"^[a-zA-Z0-9ÑñÁÀÄáàäÉÉËéèëÍÍÏíÌïÓÒÖóòöÚÙÜúùü.,:;\d ]{1,4000}$";
        protected string _TextOnly = @"^[a-zA-Z0-9ÑñÁÀÄáàäÉÉËéèëÍÍÏíÌïÓÒÖóòöÚÙÜúùü.,@:;_\-\/\d ]*$";
        protected string _ArrayNumberOnly = @"^[\d|]*$";
        protected string _noCharacters = "“!\"()=?{[]}+#-.,<'_:;>~|@";
        protected string _NoHTML = @"<(.|\n)*?>";
        protected string _phanumeric = @"[0-9a-zA-Z\s]*";

        public string inversaCaracteresEspeciales(string texto)
        {
            string respuesta = texto.Replace("&amp;", "&")
                            .Replace("&#35;", "#")
                            .Replace("&lt;", "<")
                            .Replace("&gt;", ">")
                            .Replace("&quot;", "\"")
                            .Replace("&#33;", "!")
                            .Replace("&#36;", "$")
                            .Replace("&#37;", "%")
                            .Replace("&#39;", "'")
                            .Replace("&#40;", "(")
                            .Replace("&#41;", ")")
                            .Replace("&#42;", "*")
                            .Replace("&#43;", "+")
                            .Replace("&#44;", ",")
                            .Replace("&#45;", "-")
                            .Replace("&#46;", ".")
                            .Replace("&#47;", "/")
                            .Replace("&#58;", ":")
                            .Replace("&#61;", "=")
                            .Replace("&#63;", "?")
                            .Replace("&#91;", "[")
                            .Replace("&#93;", "]")
                            .Replace("&#94;", "^")
                            .Replace("&#95;", "_")
                            .Replace("&#123;", "{")
                            .Replace("&#124;", "|")
                            .Replace("&#125;", "}")
                            .Replace("&#126;", "~")
                            .Replace("&iquest;", "¿")
                            .Replace("&iexcl;", "¡");
            respuesta = Regex.Replace(respuesta, @"<[^>]*>", String.Empty);

            return respuesta;
        }

        public string quitaCaracteresEspeciales(string texto)
        {
            string respuesta = Regex.Replace(texto, @"<[^>]*>", String.Empty);
            respuesta = Regex.Replace(respuesta, @"&lt;[^>]*&gt;", String.Empty);
            respuesta = Regex.Replace(respuesta, @"&#60;[^>]*&#62;", String.Empty);
            respuesta = respuesta.Replace("&", "&amp;")
                        .Replace("#", "&#35;")
                //.Replace("\n", "&#salto;")
                        .Replace("\\", "")
                        .Replace("<", "&lt;")
                        .Replace(">", "&gt;")
                        .Replace("\"", "&quot;")
                        .Replace("!", "&#33;")
                        .Replace("$", "&#36;")
                        .Replace("%", "&#37;")
                        .Replace("'", "&#39;")
                        .Replace("(", "&#40;")
                        .Replace(")", "&#41;")
                        .Replace("*", "&#42;")
                        .Replace("+", "&#43;")
                        .Replace(",", "&#44;")
                        .Replace("-", "&#45;")
                        .Replace(".", "&#46;")
                        .Replace("/", "&#47;")
                        .Replace(":", "&#58;")
                        .Replace("=", "&#61;")
                        .Replace("?", "&#63;")
                        .Replace("[", "&#91;")
                        .Replace("[", "&#93;")
                        .Replace("^", "&#94;")
                        .Replace("_", "&#95;")
                        .Replace("_", "&#95;")
                        .Replace("{", "&#123;")
                        .Replace("|", "&#124;")
                        .Replace("}", "&#125;")
                        .Replace("~", "&#126;")
                        .Replace("¿", "&iquest;")
                        .Replace("¡", "&iexcl;");

            return respuesta;
        }

        public string validarNumero(string texto)
        {
            string respuesta = string.Empty;

            if (Regex.IsMatch(texto, _NumbersOnly))
                respuesta = Regex.Match(texto, _NumbersOnly).Value;

            return respuesta;
        }

        public string validarDecimal(string texto)
        {
            string respuesta = string.Empty;

            if (Regex.IsMatch(texto, _NumbersDecimal))
                respuesta = Regex.Match(texto, _NumbersDecimal).Value;

            return respuesta;
        }

        public string validarFecha(string texto)
        {
            string respuesta = string.Empty;

            if (Regex.IsMatch(texto, _DateOnly))
                respuesta = Regex.Match(texto, _DateOnly).Value;

            return respuesta;
        }

        public Dispositivo getDispositivo() {
            return new Dispositivo();
        }

        //public string getDispositivo()
        //{
        //    string ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        //    if (ip.Equals("::1"))
        //        ip = "127.0.0.1";
        //    string navegador = "Browser Capabilities"
        //                    + "|Type:" + HttpContext.Current.Request.Browser.Type
        //                    + "|Name:" + HttpContext.Current.Request.Browser.Browser
        //                    + "|Version:" + HttpContext.Current.Request.Browser.Version
        //                    + "|Major Version:" + HttpContext.Current.Request.Browser.MajorVersion.ToString()
        //                    + "|Minor Version:" + HttpContext.Current.Request.Browser.MinorVersion.ToString();
        //    IPAddress myIP = IPAddress.Parse(ip);
        //    IPHostEntry GetIPHost = Dns.GetHostEntry(myIP);
        //    List<string> compName = GetIPHost.HostName.ToString().Split('.').ToList();
        //    string pcName = compName.First();

        //    var objDispositivo = new {
        //        ip = ip,
        //        navegador = navegador,
        //        plataforma = HttpContext.Current.Request.Browser.Platform,
        //        pcName = pcName,
        //        dominioRed = Environment.UserDomainName,
        //        usuarioRed = Environment.UserName,
        //        maquinaRed = Environment.MachineName
        //    };

        //    return JsonConvert.SerializeObject(objDispositivo);
        //}

        //public string getIP()
        //{
        //    try
        //    {
        //        string ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        //        if (ip.Equals("::1"))
        //            ip = "127.0.0.1";
        //        return ip;
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}

        //public string getNavegador()
        //{
        //    try
        //    {
        //        return "Browser Capabilities"
        //                    + "|Type:" + HttpContext.Current.Request.Browser.Type
        //                    + "|Name:" + HttpContext.Current.Request.Browser.Browser
        //                    + "|Version:" + HttpContext.Current.Request.Browser.Version
        //                    + "|Major Version:" + HttpContext.Current.Request.Browser.MajorVersion.ToString()
        //                    + "|Minor Version:" + HttpContext.Current.Request.Browser.MinorVersion.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}

        //public string getPlataforma()
        //{
        //    try
        //    {
        //        return HttpContext.Current.Request.Browser.Platform;
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}

        //public string getPCName()
        //{
        //    try
        //    {
        //        IPAddress myIP = IPAddress.Parse(getIP());
        //        IPHostEntry GetIPHost = Dns.GetHostEntry(myIP);
        //        List<string> compName = GetIPHost.HostName.ToString().Split('.').ToList();
        //        return compName.First();
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}

        //public string getDominioRed()
        //{
        //    try
        //    {
        //        return Environment.UserDomainName;
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}

        //public string getUsuarioRed()
        //{
        //    try
        //    {
        //        return Environment.UserName;
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}

        //public string getMaquinaRed()
        //{
        //    try
        //    {
        //        return Environment.MachineName;
        //    }
        //    catch (Exception ex)
        //    {
        //        return string.Empty;
        //    }
        //}


        public bool enviarCorreo(string to, string from,
            string Subject, string Body,
            string[] Attachment, string cc,
            string bcc, string Page,
            string PersonId, string UserName,
            string IP, string Accion)
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="to"></param>
            /// <param name="from"></param>
            /// <param name="Subject"></param>
            /// <param name="Body"></param>
            /// <param name="Attachment"></param>
            /// <param name="cc"></param>
            /// <param name="bcc"></param>
            /// <param name="Page"></param>
            /// <param name="PersonId"></param>
            /// <param name="UserName"></param>
            /// <param name="IP"></param>
            /// <param name="Accion"></param>}
            /// <returns></returns>
            /// 
            bool process = false;
            string AttachFile = String.Empty;

            DataTable dtResult = new DataTable();
            StringBuilder sqlParameter = new StringBuilder();
            string strResult = String.Empty;

            MailAddress _To = null;
            MailAddress _cc = null;
            string[] vecEmail = null;


            if (to.Contains(","))
            {
                vecEmail = to.Split(',');
                for (int i = 0; i < vecEmail.Length; i++)
                {
                    if (i == 0)
                    {
                        if (vecEmail[i].Contains("@"))
                        {
                            _To = new MailAddress(vecEmail[i]);
                        }

                        break;
                    }
                }
            }
            else
                _To = new MailAddress(to);


            MailAddress _From = new MailAddress(from, "StarkPBX");
            MailMessage message = new MailMessage(_From, _To);

            if (vecEmail != null)
            {
                for (int i = 1; i < vecEmail.Length; i++)
                {
                    if (vecEmail[i] != String.Empty)
                    {
                        if (vecEmail[i].Contains("@"))
                        {
                            _cc = new MailAddress(vecEmail[i]);
                            message.CC.Add(_cc);
                        }
                    }
                }
            }


            try
            {


                #region  COPIA DE CORREO

                /**************************************************************************/
                //                       COPIA DE CORREO
                /**************************************************************************/


                if (cc != String.Empty)
                {
                    if (cc.Contains(","))
                    {
                        vecEmail = cc.Split(',');

                        if (vecEmail != null)
                        {
                            for (int i = 0; i < vecEmail.Length; i++)
                            {
                                if (vecEmail[i] != String.Empty)
                                {
                                    if (vecEmail[i].Contains("@"))
                                    {
                                        _cc = new MailAddress(vecEmail[i]);
                                        message.CC.Add(_cc);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        _cc = new MailAddress(cc);
                        message.CC.Add(_cc);
                    }
                }

                /**************************************************************************/
                //                    FIN  COPIA DE CORREO
                /**************************************************************************/


                #endregion


                #region COPIA DE CORREO OCULTO

                /**************************************************************************/
                //                       COPIA DE CORREO OCULTO
                /**************************************************************************/


                if (bcc != String.Empty)
                {
                    MailAddress _Bcc = null;

                    if (bcc.Contains(","))
                    {
                        vecEmail = bcc.Split(',');

                        if (vecEmail != null)
                        {
                            for (int i = 0; i < vecEmail.Length; i++)
                            {
                                if (vecEmail[i] != String.Empty)
                                {
                                    if (vecEmail[i].Contains("@"))
                                    {
                                        _Bcc = new MailAddress(vecEmail[i]);
                                        message.Bcc.Add(_Bcc);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        _Bcc = new MailAddress(bcc);
                        message.Bcc.Add(_Bcc);
                    }
                }

                /**************************************************************************/
                //                    FIN   COPIA DE CORREO OCULTO
                /**************************************************************************/

                #endregion



                message.Subject = Subject;
                message.Body = Body;
                message.IsBodyHtml = true;
                message.Priority = MailPriority.High;

                foreach (string att in Attachment)
                {
                    message.Attachments.Add(new Attachment(att));
                    AttachFile += att + ",";
                }


                /*System.Net.Mime.ContentType mimeType = new System.Net.Mime.ContentType("text/html");
                AlternateView alternate = AlternateView.CreateAlternateViewFromString(Body, mimeType);
                message.AlternateViews.Add(alternate);*/


                SmtpClient client = new SmtpClient("200.38.122.65", 25);

                // Set EnableSsl = True if SSL is required
                // client.EnableSsl = false; // Solo si lo requiere

                // Send the Email
                client.Send(message);
                process = true;
            }
            catch (System.Net.Mail.SmtpException ex)
            {
                // throw ex;
            }

            return process;
        }

        public string EncriptaGS(string Data)
        {
            try
            {
                EncripcionGS.Encriptador objCript = new EncripcionGS.Encriptador(EncripcionGS.EncryptionAlgorithm.Rijndael);
                return objCript.Encripta(Data, ConfigurationManager.AppSettings["key"]);
            }
            catch
            {
                return string.Empty;
            }
        }

        public string DesencriptaGS(string Data, string wllave)
        {
            try
            {
                DesencripcionGS.Desencriptador objCript = new DesencripcionGS.Desencriptador(DesencripcionGS.DecryptionAlgorithm.Rijndael);
                return objCript.Desencripta(Data, wllave);
            }
            catch
            {
                return string.Empty;
            }
        }

        public bool validarDispositivo(Dispositivo dispositivo, HttpSessionStateBase sesion)
        { 
            try
            {
                if (sesion["NOCDASH_ip"] != null && sesion["NOCDASH_navegador"] != null && sesion["NOCDASH_plataforma"] != null && sesion["NOCDASH_pcName"] != null && sesion["NOCDASH_dominioRed"] != null)
                {
                    if (sesion["NOCDASH_ip"].ToString().Equals(dispositivo.getIP()) && sesion["NOCDASH_navegador"].ToString().Equals(dispositivo.getNavegador()) && sesion["NOCDASH_plataforma"].ToString().Equals(dispositivo.getPlataforma()) && sesion["NOCDASH_pcName"].ToString().Equals(dispositivo.getPCName()) && sesion["NOCDASH_dominioRed"].ToString().Equals(dispositivo.getDominioRed()))
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
            catch(Exception ex)
            { 
                return false;
            }
        }
    }
}