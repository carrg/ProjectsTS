﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace NOCDashboard.Models.Entities
{
    public class Dispositivo
    {
        public string getIP() 
        {
            try
            {
                string ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                if (ip.Equals("::1"))
                    ip = "127.0.0.1";
                return ip;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }
        public string getNavegador()
        {
            try
            {
                return "Browser Capabilities"
                            + "|Type:" + HttpContext.Current.Request.Browser.Type
                            + "|Name:" + HttpContext.Current.Request.Browser.Browser
                            + "|Version:" + HttpContext.Current.Request.Browser.Version
                            + "|Major Version:" + HttpContext.Current.Request.Browser.MajorVersion.ToString()
                            + "|Minor Version:" + HttpContext.Current.Request.Browser.MinorVersion.ToString();
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public string getPlataforma()
        {
            try
            {
                return HttpContext.Current.Request.Browser.Platform;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public string getPCName()
        {
            try
            {
                IPAddress myIP = IPAddress.Parse(getIP());
                IPHostEntry GetIPHost = Dns.GetHostEntry(myIP);
                List<string> compName = GetIPHost.HostName.ToString().Split('.').ToList();
                return compName.First();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string getDominioRed()
        {
            try
            {
                return Environment.UserDomainName;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public string getUsuarioRed()
        {
            try
            {
                return Environment.UserName;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public string getMaquinaRed()
        {
            try
            {
                return Environment.MachineName;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }
    }
}