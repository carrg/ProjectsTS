﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace NOCDashboard.Models.Entities
{
    public class ExceptionEntitie
    {
        [DefaultValue(false)]
        public bool existeError { set; get; }
        public int idUsuario { set; get; }
        public string tipo { set; get; }
        public string archivo { set; get; }
        public int linea { set; get; }
        public int columna { set; get; }
        public string error { set; get; }
        public string fecha { set; get; }
        public string idDispositivo { set; get; }
        public string detalle { set; get; }
    }
}