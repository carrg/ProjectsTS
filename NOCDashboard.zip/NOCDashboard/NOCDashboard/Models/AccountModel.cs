﻿using NOCDashboard.Libs;
using NOCDashboard.Models.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Windows.Forms;

namespace NOCDashboard.Models
{
    public class AccountModel : DB
    {
        private Dispositivo dispositivo = null;

        public AccountModel(Dispositivo dispositivo) : base(dispositivo)
        {
            this.dispositivo = dispositivo;
           
        }

        public IEnumerable<int> validarAccesos(String noEmpleado, ref ExceptionEntitie exEnt)
        {
            IEnumerable<int> respuesta = Enumerable.Empty<int>();
            SqlCommand command = null;
            SqlDataReader reader = null;

            if (this.connectionDB.State == ConnectionState.Closed)
                this.connectionDB.Open();
         
            try
            {
                command = new SqlCommand();
                command.Connection = this.connectionDB;
                command.CommandText = "NOCDash.ValidarAcceso";
                command.Parameters.AddWithValue("@noEmpleado", noEmpleado);
                command.Parameters.AddWithValue("@ip", this.dispositivo.getIP());
                command.Parameters.AddWithValue("@navegador", this.dispositivo.getNavegador());
                command.Parameters.AddWithValue("@plataforma", this.dispositivo.getPlataforma());
                command.Parameters.AddWithValue("@pcName", this.dispositivo.getPCName());
                command.Parameters.AddWithValue("@dominioRed", this.dispositivo.getDominioRed());
                command.CommandType = CommandType.StoredProcedure;
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    if (reader.HasRows)
                    {
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(0) });
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(1) });
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(2) });
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(3) });
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(4) });
                    }
                    else
                        throw new Exception("Exception: reader.HasRows: el objeto Reader no contiene ningunla fila");
                }
                else
                    throw new Exception("Exception: reader.Read(): No se puede leer el objeto Reader");
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (this.connectionDB.State == ConnectionState.Open)
                    this.connectionDB.Close();
            }

            return respuesta;
        }

        public IEnumerable<int> nuevaSesion(int idUsuario, int idDispositivo, ref ExceptionEntitie exEnt)
        {
            IEnumerable<int> respuesta = Enumerable.Empty<int>();
            SqlCommand command = null;
            SqlDataReader reader = null;

            if (this.connectionDB.State == ConnectionState.Closed)
                this.connectionDB.Open();

            try
            {
                command = new SqlCommand();
                command.Connection = this.connectionDB;
                command.CommandText = "NOCDash.nuevaSesion";
                command.Parameters.AddWithValue("@idUsuario", idUsuario);
                command.Parameters.AddWithValue("@idDispositivo", idDispositivo);
                command.CommandType = CommandType.StoredProcedure;
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    if (reader.HasRows)
                    {
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(0) });
                        respuesta = respuesta.Concat(new[] { reader.GetInt32(1) });
                    }
                    else
                        throw new Exception("Exception: reader.HasRows: el objeto Reader no contiene ningunla fila");
                }
                else
                    throw new Exception("Exception: reader.Read(): No se puede leer el objeto Reader");
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                exEnt.existeError = true;
                exEnt.tipo = ex.GetType().FullName;
                exEnt.archivo = trace.GetFrame(0).GetMethod().ReflectedType.FullName;
                exEnt.error = ex.Message;
                exEnt.linea = trace.GetFrame(0).GetFileLineNumber();
                exEnt.columna = trace.GetFrame(0).GetFileColumnNumber();
                exEnt.detalle = ex.ToString();
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                if (command != null)
                    command.Dispose();
                if (this.connectionDB.State == ConnectionState.Open)
                    this.connectionDB.Close();
            }

            return respuesta;
        }
    }
}